-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: dfsdata
-- ------------------------------------------------------
-- Server version	8.0.32-0ubuntu0.22.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Comments`
--

DROP TABLE IF EXISTS `Comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Comments` (
  `comment_id` varchar(255) NOT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `dataset_version_id` varchar(255) DEFAULT NULL,
  `version_name` varchar(255) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comments`
--

LOCK TABLES `Comments` WRITE;
/*!40000 ALTER TABLE `Comments` DISABLE KEYS */;
INSERT INTO `Comments` VALUES ('1125f401-16c4-42df-ae98-21360147f2af','56106f4d-a316-4871-b7ec-3f3eb85e3a65','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a','a65bacae-534a-4b2f-92e4-b475fcaff163','version 1','This is comments for version 1'),('853622d8-d01b-4732-9b6e-97b22ac1de9c','aee44668-b6e8-4c84-8099-8551fff5cda5','b29b8e83-8e8e-45f2-abdb-68e8bf0db18c','d75d389c-b30b-4065-8663-669ece7511c6','version 5','This is comments for version 5'),('8a288925-fe00-4c65-a215-ad48245a5cd9','025107b6-82ad-47de-9848-2c73eef6d721','6ac3f1ce-54ed-4d3a-ac35-fc407f220496','15e9eef2-31ce-4812-8487-7f2082238bc7','version 4','This is comments for version 4'),('8f7f2c2f-ef3e-489e-9cdc-965449b2778e','aee44668-b6e8-4c84-8099-8551fff5cda5','7d22f4c1-cb22-4855-a0ff-d160df7a1f07','03b89f99-0b5a-4f51-ad27-37573c870931','version 2','This is comments for version 2'),('e743ad4c-ca63-4e8a-8ea9-6e3f0c755e72','5c4a30ca-b253-4fc4-b2a8-258f0b482fa3','7c758748-7c80-424e-bef9-dabfa0809cf5','f9813aae-bbbf-437e-998d-e1a5177a49f3','version 3','This is comments for version 3');
/*!40000 ALTER TABLE `Comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContactUs`
--

DROP TABLE IF EXISTS `ContactUs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ContactUs` (
  `NAME` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `MESSAGE` varchar(255) DEFAULT NULL,
  `CreationDate` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContactUs`
--

LOCK TABLES `ContactUs` WRITE;
/*!40000 ALTER TABLE `ContactUs` DISABLE KEYS */;
INSERT INTO `ContactUs` VALUES ('ad','ADADFA@FADFA','dsasfadsfasd','2022-12-22 23:52:09'),('Aryan','aryandubey2389@gmail.com','dasfasdfad','2022-12-22 23:51:35'),('Aryan','asdfasd@asfadsfa','ssdfsdgsfd','2022-12-22 23:51:35');
/*!40000 ALTER TABLE `ContactUs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DataRequests`
--

DROP TABLE IF EXISTS `DataRequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DataRequests` (
  `request_id` varchar(255) NOT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `dataset_version_id` varchar(255) DEFAULT NULL,
  `requester_id` varchar(255) DEFAULT NULL,
  `approved_status` varchar(255) DEFAULT 'null',
  `latest_status_change_date` datetime DEFAULT NULL,
  `request_creation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DataRequests`
--

LOCK TABLES `DataRequests` WRITE;
/*!40000 ALTER TABLE `DataRequests` DISABLE KEYS */;
INSERT INTO `DataRequests` VALUES ('59313da2-7eeb-47a4-9572-f94094e78458','7c758748-7c80-424e-bef9-dabfa0809cf5','d75d389c-b30b-4065-8663-669ece7511c6','56106f4d-a316-4871-b7ec-3f3eb85e3a65','APPROVED','2022-06-12 06:14:27','2022-06-14 06:14:27'),('75980da4-326f-480d-b5da-9c46b905604d','7c758748-7c80-424e-bef9-dabfa0809cf5','d75d389c-b30b-4065-8663-669ece7511c6','aee44668-b6e8-4c84-8099-8551fff5cda5','PENDING','2022-06-14 06:14:27','2022-06-14 06:14:27');
/*!40000 ALTER TABLE `DataRequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Dataset`
--

DROP TABLE IF EXISTS `Dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Dataset` (
  `dataset_id` varchar(255) NOT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `reference_list` mediumtext,
  `dataset_name` varchar(255) DEFAULT NULL,
  `dataset_description` text,
  `public` tinyint(1) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `dataset_data` longblob,
  `dataset_format` varchar(255) DEFAULT NULL,
  `temporary` tinyint(1) DEFAULT NULL,
  `dataset_status` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dataset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Dataset`
--

LOCK TABLES `Dataset` WRITE;
/*!40000 ALTER TABLE `Dataset` DISABLE KEYS */;
INSERT INTO `Dataset` VALUES ('2328710d-e0c6-4fa8-b28a-265b4b6fa7d1','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Thar Desert Rain','Rainfall statistics recorded across multiple regions and large timeframes in the Thar desert',1,'IAF',NULL,'csv',1,'REJECTED','Wildlife'),('2e29b4c8-45cb-4ac4-a9db-cbde45f4346b','amey.kudari@students.iiit.ac.in','none','Pudi sir meet','none',1,'none',NULL,'JSON',0,'APPROVED','asdf'),('5eb35076-59c8-4efc-b538-7c64806b9073','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Amazon Forest Animals','Animal statistics data of all animals living in Amazon Rain Forest over multiple years',1,'USAF',NULL,'csv',1,'APPROVED','Wildlife'),('6ac3f1ce-54ed-4d3a-ac35-fc407f220496','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Iris Dataset','Iris dataset is popular CV datasetset...',0,'www.kaggle.com',NULL,'jpg files format',1,'PENDING','Medical'),('761f3e86-b505-4e7a-9209-0256bd9bddd5','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','UWGMI Dataset','UWGMI dataset is medical dataset containing...',1,'www.kaggle.com',NULL,'series of snapshots of stomach, jpg files',1,'APPROVED','Medical'),('78fccd8b-04cb-4c49-a68c-417cf4f41348','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Stock Market dji','Historic data of the stock market index dji, and all stocks under dji',1,'NYSE',NULL,'csv',1,'PENDING','Stock Market'),('79ce14f1-1d4b-49b7-9298-dd3164948d60','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','MovieLens','MovieLens dataset is very popular dataset with many different movies catagorized by genre, length and many other details. They are all sliced by year released',1,'Movielens Archives',NULL,'csv',1,'APPROVED','Movies'),('7c758748-7c80-424e-bef9-dabfa0809cf5','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','EPL Dataset','EPL dataset contains tabular data ... ',0,'www.kaggle.com',NULL,'csv file format',0,'APPROVED','EPL'),('7d22f4c1-cb22-4855-a0ff-d160df7a1f07','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Cars Dataset','Cars dataset contains images of cars ... ',1,'www.kaggle.com',NULL,'jpg files format',0,'APPROVED','Vehicles'),('8636fa47-99ad-4371-a38d-e5c46618d4e0','amey.kudari2@students.iiit.ac.in','none','Amey 2','none',1,'none',NULL,'none',0,'APPROVED','asdf'),('89838ce2-22f2-49f0-ac12-b62939df4aa7','amey.kudari3@students.iiit.ac.in','-','Amey3 dataset','-',1,'-',NULL,'JSON',0,'APPROVED','asdf'),('8e79e8e3-64a0-47ef-9ff3-75e4276d1c1e','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','MonkeyPox Data','Monkey data across the world, of all new infections, deaths and recoveries. Organized by day',1,'WHO',NULL,'csv',1,'APPROVED','Medical'),('900678bf-2d8a-42dc-bb8c-42662c691d85','amey.kudari@students.iiit.ac.in','asdf','asdff','asdf',1,'asdf',NULL,'asdf',0,'APPROVED','asdf'),('b9ff8e70-028b-4ba2-bc84-97c0ef20cbce','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Covid 19 USA','Covid 19 data of USA, of all new infections, deaths and recoveries. Organized by day',1,'WHO',NULL,'csv',1,'APPROVED','Covid'),('c7d86573-fdb5-47e6-8aae-01fbacc96f7e','amey.kudari@students.iiit.ac.in','asdf','asdf','asdf',1,'asdf',NULL,'asdf',0,'APPROVED','asdf'),('cf3d753f-e5ec-4990-b58f-d2efce400e44','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Amazon Rain Forest','Data of all known animals living in Amazon rain forest',1,'USAF',NULL,'csv',1,'PENDING','Wildlife'),('cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','MovieLens Dataset','MovieLens dataset is very popular dataset ... ',1,'www.kaggle.com',NULL,'png file format',0,'APPROVED','Movies'),('d7d8bdc3-e063-463d-be10-8f929c3160c3','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Amazon Forest','Data of all trees in amazon forest aged more than 100 years in the Amazon forest',1,'USAF',NULL,'csv',1,'APPROVED','Wildlife'),('daee1427-e5ce-489c-997d-81e80028c449','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Covid 19 India','Covid 19 data of India, of all new infections, deaths and recoveries. Organized by day',1,'WHO',NULL,'csv',1,'PENDING','Covid'),('e2e55a69-e814-4042-84c1-894940bcf087','amey.kudari@students.iiit.ac.in','asdf','Name','asdf',1,'asdf',NULL,'asdf',0,'APPROVED','asdf'),('eaaa6f65-4755-4dfe-87ff-6d51641aafaf','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Stock Market Nifty 50','Historic data of the stock market index nifty 50, and all stocks under nifty 50',1,'Yahoo Finance',NULL,'csv',1,'APPROVED','Stock Market'),('f8c16077-dd1f-4085-a8af-d4ed4c3e7026','amey.kudari@students.iiit.ac.in','None','This dataset will be deleted','This is a dataset that will be deleted',1,'www.classified.com',NULL,'JSON',0,'APPROVED','Covid');
/*!40000 ALTER TABLE `Dataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DatasetGroups`
--

DROP TABLE IF EXISTS `DatasetGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DatasetGroups` (
  `group_id` varchar(255) NOT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DatasetGroups`
--

LOCK TABLES `DatasetGroups` WRITE;
/*!40000 ALTER TABLE `DatasetGroups` DISABLE KEYS */;
INSERT INTO `DatasetGroups` VALUES ('b2dfd1ac-6051-454c-bd41-41f63b0a9093','QWER','amey.kudari@students.iiit.ac.in','CREATOR'),('d3494fcf-427c-4e8f-9c03-24e4a614facc','ADSF','amey.kudari@students.iiit.ac.in','CREATOR'),('d3494fcf-427c-4e8f-9c03-24e4a614facc','ADSF','amey.kudari2@students.iiit.ac.in','MEMBER');
/*!40000 ALTER TABLE `DatasetGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DatasetVersion`
--

DROP TABLE IF EXISTS `DatasetVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DatasetVersion` (
  `dataset_version_id` varchar(255) NOT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `version_data` longblob,
  `version_data_format` varchar(255) DEFAULT NULL,
  `dataset_changes` longblob,
  `changes_format` varchar(255) DEFAULT NULL,
  `version_name` varchar(255) DEFAULT NULL,
  `abstract` text,
  `reference` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_edit` datetime DEFAULT NULL,
  `publication_names` text,
  `publication_links` text,
  PRIMARY KEY (`dataset_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DatasetVersion`
--

LOCK TABLES `DatasetVersion` WRITE;
/*!40000 ALTER TABLE `DatasetVersion` DISABLE KEYS */;
INSERT INTO `DatasetVersion` VALUES ('03b89f99-0b5a-4f51-ad27-37573c870931','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a',NULL,'JSON',NULL,'JSON','MovieLens 2.0','Newer movies from 2018 onwards are now included in the dataset','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('08e8f47d-a572-4c52-1b3e-788ed4e983c0','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','MARUTI','Historic data of MARUTI','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('15e9eef2-31ce-4812-8487-7f2082238bc7','7c758748-7c80-424e-bef9-dabfa0809cf5',NULL,'JSON',NULL,'JSON','EPL 1.0','EPL 2021-2022 matches included','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('1a5a91cd-2f3b-4124-83d1-4c2e9c71474a','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','INFY','Historic data of INFY','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('1dd90625-3fb5-4f9e-b22a-1d6cbafa6fc7','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','HINDALCO','Historic data of HINDALCO','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('249d157c-21cb-4ed2-8f46-f95614a93995','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','NTPC','Historic data of NTPC','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('505dfbe9-742c-46f8-82ad-324b34a77e0c','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TATAMOTORS','Historic data of TATAMOTORS','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('684ecc11-af05-408e-9d95-961c306f3995','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','HDFCBANK','Historic data of HDFCBANK','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('6d76b51c-6758-48dd-328c-88a767896280','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TCS','Historic data of TCS','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('7ff885d4-9597-437d-8169-caf4b68df9fd','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','HDFC','Historic data of HDFC','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('95f8dec2-96e7-4517-17a3-82374899f615','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','ICICIBANK','Historic data of ICICIBANK','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('a65bacae-534a-4b2f-92e4-b475fcaff163','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a',NULL,'JSON',NULL,'JSON','MovieLens 1.0','Newer movies from 2016 onwards are now included in the dataset','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('b33aff78-c31c-4a12-281e-53909a397e6d','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TATASTEEL','Historic data of TATASTEEL','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('c86ea044-749e-4d2b-0381-b1170fd19161','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TITAN','Historic data of TITAN','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('d09a5b24-cad7-4db4-9cb9-355092e5d4c1','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','RELIANCE','Historic data of RELIANCE','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('d545db8b-cbd6-4b7d-b5c3-810a57ea6bd2','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','SBIN','Historic data of SBIN','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('d75d389c-b30b-4065-8663-669ece7511c6','7c758748-7c80-424e-bef9-dabfa0809cf5',NULL,'JSON',NULL,'JSON','EPL 2.0','EPL 2022-2023 matches included','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('e49f014d-a6b0-458f-1478-d7cad40a1014','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','BAJFINANCE','Historic data of BAJFINANCE','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('edade22d-b012-4b44-0cb6-d1058d30f562','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','M&M','Historic data of M&M','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('f9813aae-bbbf-437e-998d-e1a5177a49f3','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a',NULL,'JSON',NULL,'JSON','MovieLens 3.0','Newer movies from 2020 onwards are now included in the dataset','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('f9a1f390-9dfc-4827-b938-fbf757693737','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','AXISBANK','Historic data of AXISBANK','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723');
/*!40000 ALTER TABLE `DatasetVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DfsUser`
--

DROP TABLE IF EXISTS `DfsUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DfsUser` (
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) NOT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `user_role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DfsUser`
--

LOCK TABLES `DfsUser` WRITE;
/*!40000 ALTER TABLE `DfsUser` DISABLE KEYS */;
INSERT INTO `DfsUser` VALUES ('Amey','Kudari','amey','amey.kudari@students.iiit.ac.in','IIIT-H','software engineer','admin'),('Amey','Kudari','amey','amey.kudari2@students.iiit.ac.in','IIIT-H','software engineer','admin'),('Amey3','Kudari','amey','amey.kudari3@students.iiit.ac.in','IIIT-H','software engineer','admin'),('Amey4','Kudari','amey','amey.kudari4@students.iiit.ac.in','IIIT-H','software engineer','user'),('User1','Lastname1','password','user1.lastname1@gmail.com','IIIT-H','normal user','user');
/*!40000 ALTER TABLE `DfsUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Domain`
--

DROP TABLE IF EXISTS `Domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Domain` (
  `domain` varchar(255) NOT NULL,
  `publication_links` text,
  `publication_names` text,
  `publication_format` varchar(255) DEFAULT NULL,
  `abstract_a` text,
  `abstarct_b` text,
  `abstract_c` text,
  `last_addition` datetime DEFAULT NULL,
  PRIMARY KEY (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Domain`
--

LOCK TABLES `Domain` WRITE;
/*!40000 ALTER TABLE `Domain` DISABLE KEYS */;
INSERT INTO `Domain` VALUES ('Covid','Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Demo domain','none','none','CSV','This is a demo domain','Delete later','delete later','2011-04-14 00:00:00'),('EPL','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Medical','Girish Varma, Anbumani Subramanian, Anoop Namboodiri, Manmohan Chandraker & C V Jawahar - IDD: A Dataset for Exploring Problems of Autonomous Navigation in Unconstrained Environments - IEEE Winter Conf. on Applications of Computer Vision (WACV 2019)','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Movies','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Stock Market','Absdf Qwer, Awer Sqer, Qsdf Qwer, S V Lajwer & S Q Awqer - SMD : Stock market historic data adjusted for stock splits','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Vehicles','','','','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Wildlife','Girish Varma, Anbumani Subramanian, Anoop Namboodiri, Manmohan Chandraker & C V Jawahar - IDD: A Dataset for Exploring Problems of Autonomous Navigation in Unconstrained Environments - IEEE Winter Conf. on Applications of Computer Vision (WACV 2019)','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27');
/*!40000 ALTER TABLE `Domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Files`
--

DROP TABLE IF EXISTS `Files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Files` (
  `upfilename` varchar(255) NOT NULL,
  `upfilenameMD` varchar(255) DEFAULT NULL,
  `filetype` varchar(255) DEFAULT NULL,
  `database_id` varchar(255) DEFAULT NULL,
  `databaseVersion_id` varchar(255) DEFAULT NULL,
  `comments` text,
  `version_name` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `created_date` varchar(255) DEFAULT NULL,
  `last_edit` varchar(255) DEFAULT NULL,
  `publication_names` text,
  `publication_links` text,
  `verification` varchar(255) DEFAULT NULL,
  `public` varchar(255) DEFAULT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`upfilename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Files`
--

LOCK TABLES `Files` WRITE;
/*!40000 ALTER TABLE `Files` DISABLE KEYS */;
INSERT INTO `Files` VALUES ('1659171950338_uploaderPage.js','1659171953324_Screenshot from 2022-07-26 22-18-20.png','asdf','eaaa6f65-4755-4dfe-87ff-6d51641aafaf','asdf','qewr','qwer','qwer','qwer','qwer','asdf','asdf','rejected','true','amey.kudari@students.iiit.ac.in'),('1659177934815_back1.jpg','1659177936601_uploaderPage.js','JSON','eaaa6f65-4755-4dfe-87ff-6d51641aafaf','my version id','This is a very nice dataset, please approve it','Version name! :D ','reference? I dont need reference','123l12 3j123 12l312','1l23kj213 l12kj31','hehe none','hehe nono','rejected','true','amey.kudari@students.iiit.ac.in'),('1659179980671_changes.zip','1659179990458_readme.md','JSON','eaaa6f65-4755-4dfe-87ff-6d51641aafaf','1.2.1','This is an updated dataset, with p values','p-value-dataset','none','12-21-2021','12-21-2021','qwerwqer','https://www.qewrqwer.com','rejected','true','amey.kudari@students.iiit.ac.in'),('1659184056031_changes.zip','1659184061702_readme.md','JSON','eaaa6f65-4755-4dfe-87ff-6d51641aafaf','1.2.3','no comments!','test dataset','no references','not avail','not avail','sfad;lqwjekqwer','https://qwer.wqerqwer.asdf.com','verified','true','amey.kudari@students.iiit.ac.in'),('1660074670316_Javascript-The-Definitive-Guide.pdf','1660074673947_1659179990458_readme.md','JSON','2328710d-e0c6-4fa8-b28a-265b4b6fa7d1','DOWNLOAD','DOWNLOAD','DOWNLOAD','DOWNLOAD','DOWNLOAD','DOWNLOAD','DOWNLOAD','DOWNLOAD','verified','DOWNLOAD','amey.kudari@students.iiit.ac.in'),('1660549592494_symbols.json','1660549621737_dfsdata.sql','JSON','8636fa47-99ad-4371-a38d-e5c46618d4e0','1.0.0','this is a test dataset','Version 1','Reference','created_data','last_edit','csv','csv','verified','true','amey.kudari2@students.iiit.ac.in'),('1660623210881_tmp.json','1660623202595_tmp.md','JSON','89838ce2-22f2-49f0-ac12-b62939df4aa7','1.0.0','This is a test dataset','Amey3 file 1','none','none','none','none','none','verified','false','amey.kudari3@students.iiit.ac.in'),('1660629925559_tmp.json','1660629949387_tmp.md','JSON','2e29b4c8-45cb-4ac4-a9db-cbde45f4346b','1.0.0','This is a test dataset, to show the functionality during meeting with pudi sir','Version 0 of pudi sir meet','None','None','None','None','None','verified','false','amey.kudari@students.iiit.ac.in');
/*!40000 ALTER TABLE `Files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ModelRequests`
--

DROP TABLE IF EXISTS `ModelRequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ModelRequests` (
  `model_id` varchar(255) DEFAULT NULL,
  `request_id` varchar(255) NOT NULL,
  `request_status` varchar(255) DEFAULT NULL,
  `request_for` varchar(255) DEFAULT NULL,
  `requester_id` varchar(255) DEFAULT NULL,
  `requestee_id` varchar(255) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ModelRequests`
--

LOCK TABLES `ModelRequests` WRITE;
/*!40000 ALTER TABLE `ModelRequests` DISABLE KEYS */;
INSERT INTO `ModelRequests` VALUES ('ASDF','ASDF1234','accepted','write','amey.kudari@students.iiit.ac.in','amey.kudari@students.iiit.ac.in',NULL);
/*!40000 ALTER TABLE `ModelRequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Models`
--

DROP TABLE IF EXISTS `Models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Models` (
  `dataset_version_id` varchar(255) DEFAULT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `model_id` varchar(255) NOT NULL,
  `model_name` varchar(255) DEFAULT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `author_name` varchar(255) DEFAULT NULL,
  `authors_names` text,
  `authors_ids` text,
  `created_datetime` varchar(255) DEFAULT NULL,
  `last_updated` varchar(255) DEFAULT NULL,
  `updates` int DEFAULT NULL,
  `jsondata` longtext,
  `group_read` tinyint(1) DEFAULT '0',
  `group_write` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Models`
--

LOCK TABLES `Models` WRITE;
/*!40000 ALTER TABLE `Models` DISABLE KEYS */;
INSERT INTO `Models` VALUES ('ASDF','ASDF','ASDF','ASDF','ASDF','ASDF','amey.kudari@students.iiit.ac.in','Amey',', Amey',', amey.kudari@students.iiit.ac.in','1663502724962','1673040502915',2,'1673040498430_Untitled.ipynb',0,0);
/*!40000 ALTER TABLE `Models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Requests`
--

DROP TABLE IF EXISTS `Requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Requests` (
  `upfilename` varchar(255) NOT NULL,
  `upfilenameMD` varchar(255) DEFAULT NULL,
  `requester` varchar(255) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `stat` varchar(255) DEFAULT NULL,
  `comment` text,
  `av1` text,
  PRIMARY KEY (`upfilename`,`requester`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Requests`
--

LOCK TABLES `Requests` WRITE;
/*!40000 ALTER TABLE `Requests` DISABLE KEYS */;
INSERT INTO `Requests` VALUES ('1659171950338_uploaderPage.js','1659171953324_Screenshot from 2022-07-26 22-18-20.png','amey.kudari@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','accepted','asdfasdf\nqwerqwer qwe\nasdf','BLANK'),('1659177934815_back1.jpg','1659177936601_uploaderPage.js','amey.kudari@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','requested','asdf','BLANK'),('1659184056031_changes.zip','1659184061702_readme.md','amey.kudari2@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','rejected','I am amey 2, I want access to this database.','BLANK'),('1660549592494_symbols.json','1660549621737_dfsdata.sql','amey.kudari@students.iiit.ac.in','amey.kudari2@students.iiit.ac.in','rejected','I want access to this database.','BLANK'),('1660623210881_tmp.json','1660623202595_tmp.md','amey.kudari@students.iiit.ac.in','amey.kudari3@students.iiit.ac.in','accepted','I am Amey, I want access to the file. ','BLANK'),('1660629925559_tmp.json','1660629949387_tmp.md','amey.kudari4@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','accepted','I am Amey4, I want access to this dataset because I want to do <abcc> research work on it','BLANK');
/*!40000 ALTER TABLE `Requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tnc`
--

DROP TABLE IF EXISTS `Tnc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Tnc` (
  `target_id` varchar(255) NOT NULL,
  `dataset_level` enum('DATASET','FILE') NOT NULL,
  `md_data` longtext,
  PRIMARY KEY (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tnc`
--

LOCK TABLES `Tnc` WRITE;
/*!40000 ALTER TABLE `Tnc` DISABLE KEYS */;
INSERT INTO `Tnc` VALUES ('eaaa6f65-4755-4dfe-87ff-6d51641aafaf','DATASET','1. ksjdnflkajs');
/*!40000 ALTER TABLE `Tnc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `dfs_user_id` varchar(255) NOT NULL,
  `dfs_user_name` varchar(255) DEFAULT NULL,
  `dfs_user_role` varchar(255) DEFAULT NULL,
  `dfs_user_about` text,
  PRIMARY KEY (`dfs_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('025107b6-82ad-47de-9848-2c73eef6d721','Pallavi','USER','Intern at IIIT Hyderabad. Undergrad at NIT'),('56106f4d-a316-4871-b7ec-3f3eb85e3a65','Garry','USER','Garry, a research student at IIIT Hyderabad.'),('5c4a30ca-b253-4fc4-b2a8-258f0b482fa3','Arpit','USER','Intern at IIIT Hyderabad. Loves anime'),('aee44668-b6e8-4c84-8099-8551fff5cda5','Rajat','USER','Intern, interested in datasets'),('d23a3e1c-bc46-4405-bfbe-2fd2af957176','Amit','ADMIN','Project Coordinator for DFS.');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-04  2:21:38
