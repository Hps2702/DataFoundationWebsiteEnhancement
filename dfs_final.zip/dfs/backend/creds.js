const MINIO_ENDPOINT = '10.8.0.31'
const MINIO_BUCKET = 'datafoundation-dev'

module.exports = {
    MINIO_BUCKET,
    MINIO_ENDPOINT,
}