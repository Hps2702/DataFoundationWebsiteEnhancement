USE dfsdata;

-- INSERT INTO User VALUES 
-- ('56106f4d-a316-4871-b7ec-3f3eb85e3a65', 'Garry', 'USER', 'Garry, a research student at IIIT Hyderabad.'),
-- ('aee44668-b6e8-4c84-8099-8551fff5cda5', 'Rajat', 'USER', 'Intern, interested in datasets'),
-- ('5c4a30ca-b253-4fc4-b2a8-258f0b482fa3', 'Arpit', 'USER', 'Intern at IIIT Hyderabad. Loves anime'),
-- ('025107b6-82ad-47de-9848-2c73eef6d721', 'Pallavi', 'USER' , 'Intern at IIIT Hyderabad. Undergrad at NIT'),
-- ('d23a3e1c-bc46-4405-bfbe-2fd2af957176', 'Amit', 'ADMIN', 'Project Coordinator for DFS.')
-- ;

INSERT INTO DfsUser VALUES
("Amey","Kudari","amey","amey.kudari@students.iiit.ac.in","IIIT-H","software engineer","admin"),
("User1","Lastname1","password","user1.lastname1@gmail.com","IIIT-H","normal user","user"),
("Amey","Kudari","amey","amey.kudari2@students.iiit.ac.in","IIIT-H","software engineer","admin"),
("Amey3","Kudari","amey","amey.kudari3@students.iiit.ac.in","IIIT-H","software engineer","admin"),
("Amey4","Kudari","amey","amey.kudari4@students.iiit.ac.in","IIIT-H","software engineer","user");

INSERT INTO Dataset VALUES
('cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a', '56106f4d-a316-4871-b7ec-3f3eb85e3a65', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723', 'MovieLens Dataset', 'MovieLens dataset is very popular dataset ... ', 1, 'www.kaggle.com', null, 'png file format', 0, 'APPROVED'),
('7d22f4c1-cb22-4855-a0ff-d160df7a1f07', 'aee44668-b6e8-4c84-8099-8551fff5cda5', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723', 'Cars Dataset', 'Cars dataset contains images of cars ... ', 1, 'www.kaggle.com', null, 'jpg files format', 0, 'APPROVED'),
('7c758748-7c80-424e-bef9-dabfa0809cf5', '5c4a30ca-b253-4fc4-b2a8-258f0b482fa3', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723', 'EPL Dataset', 'EPL dataset contains tabular data ... ', 0, 'www.kaggle.com', null, 'csv file format', 0, 'APPROVED'),
('6ac3f1ce-54ed-4d3a-ac35-fc407f220496', '025107b6-82ad-47de-9848-2c73eef6d721', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723', 'Iris Dataset', 'Iris dataset is popular CV datasetset...', 0, 'www.kaggle.com', null, 'jpg files format', 1, 'PENDING'),
('b29b8e83-8e8e-45f2-abdb-68e8bf0db18c', 'aee44668-b6e8-4c84-8099-8551fff5cda5', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723', 'UWGMI Dataset', 'UWGMI dataset is medical dataset containing...', 1, 'www.kaggle.com', null, 'series of snapshots of stomach, jpg files', 1, 'PENDING')
;

INSERT INTO DatasetVersion VALUES
('a65bacae-534a-4b2f-92e4-b475fcaff163', 'cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a', null, 'JSON', null, 'JSON', 'MovieLens 1.0', 'Newer movies from 2016 onwards are now included in the dataset', 'www.kaggle.com', '2022-06-14 06:14:27', '2022-06-14 06:14:27', 'IEEE, ICAI', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),
('03b89f99-0b5a-4f51-ad27-37573c870931', 'cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a', null, 'JSON', null, 'JSON', 'MovieLens 2.0', 'Newer movies from 2018 onwards are now included in the dataset', 'www.kaggle.com', '2022-06-14 06:14:27', '2022-06-14 06:14:27', 'IEEE, ICAI', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),
('f9813aae-bbbf-437e-998d-e1a5177a49f3', 'cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a', null, 'JSON', null, 'JSON', 'MovieLens 3.0', 'Newer movies from 2020 onwards are now included in the dataset', 'www.kaggle.com', '2022-06-14 06:14:27', '2022-06-14 06:14:27', 'IEEE, ICAI', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),
('15e9eef2-31ce-4812-8487-7f2082238bc7', '7c758748-7c80-424e-bef9-dabfa0809cf5', null, 'JSON', null, 'JSON', 'EPL 1.0', 'EPL 2021-2022 matches included', 'www.kaggle.com', '2022-06-14 06:14:27', '2022-06-14 06:14:27', 'IEEE, ICAI', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),
('d75d389c-b30b-4065-8663-669ece7511c6', '7c758748-7c80-424e-bef9-dabfa0809cf5', null, 'JSON', null, 'JSON', 'EPL 2.0', 'EPL 2022-2023 matches included', 'www.kaggle.com', '2022-06-14 06:14:27', '2022-06-14 06:14:27', 'IEEE, ICAI', 'https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723')
;

INSERT INTO DataRequests VALUES
('75980da4-326f-480d-b5da-9c46b905604d', '7c758748-7c80-424e-bef9-dabfa0809cf5', 'd75d389c-b30b-4065-8663-669ece7511c6', 'aee44668-b6e8-4c84-8099-8551fff5cda5', 'PENDING', '2022-06-14 06:14:27', '2022-06-14 06:14:27'),
('59313da2-7eeb-47a4-9572-f94094e78458', '7c758748-7c80-424e-bef9-dabfa0809cf5', 'd75d389c-b30b-4065-8663-669ece7511c6', '56106f4d-a316-4871-b7ec-3f3eb85e3a65', 'APPROVED', '2022-06-12 06:14:27', '2022-06-14 06:14:27')
;


INSERT INTO files VALUES ('cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a', 'a65bacae-534a-4b2f-92e4-b475fcaff163', 'MovieLens files', 'It contains ', 'This is a dataset for ', '9da03927-2329-4888-a9a8-f3e20f7e5041');
INSERT INTO files VALUES ('7d22f4c1-cb22-4855-a0ff-d160df7a1f07', '03b89f99-0b5a-4f51-ad27-37573c870931', 'Cars files', 'It contains ', 'This is a dataset for ', '21fc42bd-4dc5-4775-97ab-3356adc6560f');
INSERT INTO files VALUES ('7c758748-7c80-424e-bef9-dabfa0809cf5', 'f9813aae-bbbf-437e-998d-e1a5177a49f3', 'EPL files', 'It contains ', 'This is a dataset for ', '81033dfc-ef2f-4d83-95d6-041484be5a9a');
INSERT INTO files VALUES ('6ac3f1ce-54ed-4d3a-ac35-fc407f220496', '15e9eef2-31ce-4812-8487-7f2082238bc7', 'Iris files', 'It contains ', 'This is a dataset for ', '9c1b2ed5-f87a-40f3-8c1b-318476cbf2be');
INSERT INTO files VALUES ('b29b8e83-8e8e-45f2-abdb-68e8bf0db18c', 'd75d389c-b30b-4065-8663-669ece7511c6', 'UWGMI files', 'It contains ', 'This is a dataset for ', 'e67a422d-aa7d-4123-97ef-4a90e4a4f1d7');

INSERT INTO Comments VALUES ('1125f401-16c4-42df-ae98-21360147f2af', '56106f4d-a316-4871-b7ec-3f3eb85e3a65', 'cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a', 'a65bacae-534a-4b2f-92e4-b475fcaff163', 'version 1', 'This is comments for version 1');
INSERT INTO Comments VALUES ('8f7f2c2f-ef3e-489e-9cdc-965449b2778e', 'aee44668-b6e8-4c84-8099-8551fff5cda5', '7d22f4c1-cb22-4855-a0ff-d160df7a1f07', '03b89f99-0b5a-4f51-ad27-37573c870931', 'version 2', 'This is comments for version 2');
INSERT INTO Comments VALUES ('e743ad4c-ca63-4e8a-8ea9-6e3f0c755e72', '5c4a30ca-b253-4fc4-b2a8-258f0b482fa3', '7c758748-7c80-424e-bef9-dabfa0809cf5', 'f9813aae-bbbf-437e-998d-e1a5177a49f3', 'version 3', 'This is comments for version 3');
INSERT INTO Comments VALUES ('8a288925-fe00-4c65-a215-ad48245a5cd9', '025107b6-82ad-47de-9848-2c73eef6d721', '6ac3f1ce-54ed-4d3a-ac35-fc407f220496', '15e9eef2-31ce-4812-8487-7f2082238bc7', 'version 4', 'This is comments for version 4');
INSERT INTO Comments VALUES ('853622d8-d01b-4732-9b6e-97b22ac1de9c', 'aee44668-b6e8-4c84-8099-8551fff5cda5', 'b29b8e83-8e8e-45f2-abdb-68e8bf0db18c', 'd75d389c-b30b-4065-8663-669ece7511c6', 'version 5', 'This is comments for version 5');

INSERT INTO Models VALUES ('a65bacae-534a-4b2f-92e4-b475fcaff163', 'versions 1 and 2', '24ce1949-3707-4c59-a3f8-6f38992a8e44', '48fa4a0f-6c79-4fe2-a304-afd000b876ed', '152815c5-c5a8-483e-9e3c-708912b796d4', 'model 1', '56106f4d-a316-4871-b7ec-3f3eb85e3a65', 'Garry', 'Garry', '56106f4d-a316-4871-b7ec-3f3eb85e3a65', '2010-10-28 10:12:19', '2012-10-28 10:12:19', '2', 'This is details of model 1');
INSERT INTO Models VALUES ('03b89f99-0b5a-4f51-ad27-37573c870931', 'versions 2 and 3', 'e9682d1c-794b-44e3-a63a-f0fb3886e05a', 'bc1aa274-722c-496f-86f3-65c09a4582f0', '5bce1c91-c150-49f3-92c1-282087d68b93', 'model 2', 'aee44668-b6e8-4c84-8099-8551fff5cda5', 'Rajat', 'Rajat', 'aee44668-b6e8-4c84-8099-8551fff5cda5', '2014-11-24 08:11:05', '2017-11-24 08:11:05', '3', 'This is details of model 2');
INSERT INTO Models VALUES ('f9813aae-bbbf-437e-998d-e1a5177a49f3', 'versions 3 and 4', '5dc647d5-a14a-4b16-a4ad-46cd1820a2aa', '50201c31-f07b-4312-9e21-a6ad019392bc', '68dd9fae-3963-445c-9032-79c770013c50', 'model 3', '5c4a30ca-b253-4fc4-b2a8-258f0b482fa3', 'Arpit', 'Arpit', '5c4a30ca-b253-4fc4-b2a8-258f0b482fa3', '2012-02-21 09:12:20', '2015-02-21 09:12:20', '1', 'This is details of model 3');
INSERT INTO Models VALUES ('15e9eef2-31ce-4812-8487-7f2082238bc7', 'versions 1 and 2', '6658dea1-8634-4efc-b89a-a3d7a1ecaf0d', '6546cce9-4324-4909-b048-874f67b780c8', '7360f59f-36dc-4dc4-b7f7-f53b72d6a64a', 'model 4', '025107b6-82ad-47de-9848-2c73eef6d721', 'Pallavi', 'Pallavi', '025107b6-82ad-47de-9848-2c73eef6d721', '2009-04-25 21:10:30', '2013-04-25 21:10:30', '2', 'This is details of model 4');
INSERT INTO Models VALUES ('d75d389c-b30b-4065-8663-669ece7511c6', 'versions 1 and 5', 'bb411b13-126a-4c81-97aa-50e0d5874ce0', 'b8ffcbe7-91e9-4e08-872e-d49f8866346f', '7adaff16-88cb-41c5-a948-91cd6023a317', 'model 5', 'd23a3e1c-bc46-4405-bfbe-2fd2af957176', 'Amit', 'Amit', 'd23a3e1c-bc46-4405-bfbe-2fd2af957176', '2015-05-10 19:08:25', '2021-05-10 19:08:25', '4', 'This is details of model 5');
