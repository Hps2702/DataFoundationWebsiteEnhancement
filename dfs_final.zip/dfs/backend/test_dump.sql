-- LOCK TABLES `Files` WRITE;
INSERT INTO `Files` VALUES ('Myfile.js','MyFile.png','png','id1','idv1','no comment','v1','no ref','2008-11-11','2008-11-11','publ1','no link','rejected','true','amey.kudari@students.iiit.ac.in')
-- UNLOCK TABLES;


LOCK TABLES `Dataset` WRITE;
/*!40000 ALTER TABLE `Dataset` DISABLE KEYS */;
INSERT INTO `Dataset` VALUES ('id1','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','This is a test dataset','Test Data-1',1,'SV',NULL,'csv',1,'APPROVED','MyDomain')
/*!40000 ALTER TABLE `Dataset` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `Requests` WRITE;
/*!40000 ALTER TABLE `Dataset` DISABLE KEYS */;
INSERT INTO `Requests` VALUES ('Myfile.js','Myfile.js','amey.kudari@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','BLANK','MY test data','BLANK');
/*!40000 ALTER TABLE `Dataset` ENABLE KEYS */;
UNLOCK TABLES