-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: dfsdata
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Comments`
--

DROP TABLE IF EXISTS `Comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Comments` (
  `comment_id` varchar(255) NOT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `dataset_version_id` varchar(255) DEFAULT NULL,
  `version_name` varchar(255) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comments`
--

LOCK TABLES `Comments` WRITE;
/*!40000 ALTER TABLE `Comments` DISABLE KEYS */;
INSERT INTO `Comments` VALUES ('1125f401-16c4-42df-ae98-21360147f2af','56106f4d-a316-4871-b7ec-3f3eb85e3a65','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a','a65bacae-534a-4b2f-92e4-b475fcaff163','version 1','This is comments for version 1'),('853622d8-d01b-4732-9b6e-97b22ac1de9c','aee44668-b6e8-4c84-8099-8551fff5cda5','b29b8e83-8e8e-45f2-abdb-68e8bf0db18c','d75d389c-b30b-4065-8663-669ece7511c6','version 5','This is comments for version 5'),('8a288925-fe00-4c65-a215-ad48245a5cd9','025107b6-82ad-47de-9848-2c73eef6d721','6ac3f1ce-54ed-4d3a-ac35-fc407f220496','15e9eef2-31ce-4812-8487-7f2082238bc7','version 4','This is comments for version 4'),('8f7f2c2f-ef3e-489e-9cdc-965449b2778e','aee44668-b6e8-4c84-8099-8551fff5cda5','7d22f4c1-cb22-4855-a0ff-d160df7a1f07','03b89f99-0b5a-4f51-ad27-37573c870931','version 2','This is comments for version 2'),('e743ad4c-ca63-4e8a-8ea9-6e3f0c755e72','5c4a30ca-b253-4fc4-b2a8-258f0b482fa3','7c758748-7c80-424e-bef9-dabfa0809cf5','f9813aae-bbbf-437e-998d-e1a5177a49f3','version 3','This is comments for version 3');
/*!40000 ALTER TABLE `Comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContactUs`
--

DROP TABLE IF EXISTS `ContactUs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ContactUs` (
  `NAME` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `MESSAGE` varchar(255) DEFAULT NULL,
  `CreationDate` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`EMAIL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContactUs`
--

LOCK TABLES `ContactUs` WRITE;
/*!40000 ALTER TABLE `ContactUs` DISABLE KEYS */;
INSERT INTO `ContactUs` VALUES ('ad','ADADFA@FADFA','dsasfadsfasd','2022-12-22 23:52:09'),('Aryan','aryandubey2389@gmail.com','dasfasdfad','2022-12-22 23:51:35'),('Aryan','asdfasd@asfadsfa','ssdfsdgsfd','2022-12-22 23:51:35');
/*!40000 ALTER TABLE `ContactUs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DataRequests`
--

DROP TABLE IF EXISTS `DataRequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DataRequests` (
  `request_id` varchar(255) NOT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `dataset_version_id` varchar(255) DEFAULT NULL,
  `requester_id` varchar(255) DEFAULT NULL,
  `approved_status` varchar(255) DEFAULT 'null',
  `latest_status_change_date` datetime DEFAULT NULL,
  `request_creation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DataRequests`
--

LOCK TABLES `DataRequests` WRITE;
/*!40000 ALTER TABLE `DataRequests` DISABLE KEYS */;
INSERT INTO `DataRequests` VALUES ('59313da2-7eeb-47a4-9572-f94094e78458','7c758748-7c80-424e-bef9-dabfa0809cf5','d75d389c-b30b-4065-8663-669ece7511c6','56106f4d-a316-4871-b7ec-3f3eb85e3a65','APPROVED','2022-06-12 06:14:27','2022-06-14 06:14:27'),('75980da4-326f-480d-b5da-9c46b905604d','7c758748-7c80-424e-bef9-dabfa0809cf5','d75d389c-b30b-4065-8663-669ece7511c6','aee44668-b6e8-4c84-8099-8551fff5cda5','PENDING','2022-06-14 06:14:27','2022-06-14 06:14:27');
/*!40000 ALTER TABLE `DataRequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Dataset`
--

DROP TABLE IF EXISTS `Dataset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Dataset` (
  `dataset_id` varchar(255) NOT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `reference_list` mediumtext,
  `dataset_name` varchar(255) DEFAULT NULL,
  `dataset_description` text,
  `public` tinyint(1) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `dataset_data` longblob,
  `dataset_format` varchar(255) DEFAULT NULL,
  `temporary` tinyint(1) DEFAULT NULL,
  `dataset_status` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dataset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Dataset`
--

LOCK TABLES `Dataset` WRITE;
/*!40000 ALTER TABLE `Dataset` DISABLE KEYS */;
INSERT INTO `Dataset` VALUES ('0b412fb6-7993-44fb-ad5f-1e2a3c776c6b','raghunath.iiit@gmail.com','NA','a1','Sample dataset',1,'NA',NULL,'pdf',0,'APPROVED','Medical'),('2198225a-e2d4-45e7-ac68-301e86b6fb9d','gundimeda.venugopal@ihub-data.iiit.ac.in','none','Convex optimization','Convex optimization',1,'https://web.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf',NULL,'pdf',0,'APPROVED','Vehicles'),('2328710d-e0c6-4fa8-b28a-265b4b6fa7d1','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Thar Desert Rain','Rainfall statistics recorded across multiple regions and large timeframes in the Thar desert',1,'IAF',NULL,'csv',1,'REJECTED','Wildlife'),('2ddff60f-b79d-475c-b1ec-1cbd01d2017d','belaal.ali@gmail.com','The circadian rhythm of gene expression in mesenchymal stem cells.','The circadian rhythm of gene expression in mesenchymal stem cells.','The circadian rhythm of gene expression in mesenchymal stem cells.ΠThe circadian rhythm of gene expression in mesenchymal stem cells.',1,'The circadian rhythm of gene expression in mesenchymal stem cells.',NULL,'CSV',0,'APPROVED','Medical'),('2e29b4c8-45cb-4ac4-a9db-cbde45f4346b','amey.kudari@students.iiit.ac.in','none','Pudi sir meet','none',1,'none',NULL,'JSON',0,'APPROVED','asdf'),('36ba411b-1a45-4b0e-9528-4f2529b8073c','raghunath.iiit@gmail.com','None','Healthcare1','This is a sample health care dataset. This is a sample health care dataset. This is a sample health care dataset. This is a sample health care dataset. This is a sample health care dataset. This is a sample health care dataset. This is a sample health care dataset. This is a sample health care dataset. This is a sample health care dataset.',1,'http://datafoundation-dev.iiit.ac.in/add-dataset',NULL,'csv',0,'APPROVED','Medical'),('3a8ad838-3515-463a-9890-56cab8a8cf36','govind.krishnan@ihub-data.iiit.ac.in','TBD','iRASTE-DAC-test','this is a test dataset for validating, before we launch our iRASTE NXT Data Analytics challenge portalΠTBDΠ',1,'TBD',NULL,'CSV',0,'APPROVED','Vehicles'),('43c25436-9e97-413b-ad59-341284830bfc','pa@gmail.com','Na','d2','Sample',1,'NA',NULL,'pdf',0,'APPROVED','Medical'),('456b1270-816f-44fd-a020-e8b3321c6b69','amey.kudari@students.iiit.ac.in','ADSFASDF','ASDFASDF','ASDFQWER QWER QWER QWER \' ewq qwer asdf\' asd fasd fasdf qs\'ewr qwer\' qesa\'df eas\'df \'asdf ',1,'DFS',NULL,'CSV',0,'APPROVED','EPL'),('5eb35076-59c8-4efc-b538-7c64806b9073','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Amazon Forest Animals','Animal statistics data of all animals living in Amazon Rain Forest over multiple years',1,'USAF',NULL,'csv',1,'APPROVED','Wildlife'),('6a7d99df-37ea-4ca8-8586-07deb893e678','akshitsinha2801@gmail.com','A','A','A',1,'A',NULL,'CSV',0,'APPROVED','Covid'),('6ac3f1ce-54ed-4d3a-ac35-fc407f220496','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Iris Dataset','Iris dataset is popular CV datasetset...',0,'www.kaggle.com',NULL,'jpg files format',1,'PENDING','Medical'),('71bbc60c-1221-4f7c-874a-df1e27ced76b','amey.kudari@students.iiit.ac.in','NONE','TEST COVID','THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. THIS IS A DESCRIPTION. ΠTHIS IS YET ANOTHER DESCRIPTION. THIS IS YET ANOTHER DESCRIPTION. THIS IS YET ANOTHER DESCRIPTION. THIS IS YET ANOTHER DESCRIPTION. THIS IS YET ANOTHER DESCRIPTION. THIS IS YET ANOTHER DESCRIPTION. Π',1,'None',NULL,'CSV',0,'APPROVED','Covid'),('73d30de2-e291-4981-957e-54beeb0ec94d','amey.kudari@students.iiit.ac.in','none','TEST_AMEY_DATASET','This is a description.',1,'none',NULL,'CSV',0,'APPROVED','Covid'),('74e89f3c-d1b4-4ccb-85cb-f16962ceb6d9','deepika.nanduri@ihub-data.iiit.ac.in','1213','Deepika','ΠΠΠ',1,'weq',NULL,'XML',0,'APPROVED','EPL'),('761f3e86-b505-4e7a-9209-0256bd9bddd5','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','UWGMI Dataset','UWGMI dataset is medical dataset containing...',1,'www.kaggle.com',NULL,'series of snapshots of stomach, jpg files',1,'APPROVED','Medical'),('78fccd8b-04cb-4c49-a68c-417cf4f41348','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Stock Market dji','Historic data of the stock market index dji, and all stocks under dji',1,'NYSE',NULL,'csv',1,'PENDING','Stock Market'),('79ce14f1-1d4b-49b7-9298-dd3164948d60','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','MovieLens','MovieLens dataset is very popular dataset with many different movies catagorized by genre, length and many other details. They are all sliced by year released',1,'Movielens Archives',NULL,'csv',1,'APPROVED','Movies'),('7c758748-7c80-424e-bef9-dabfa0809cf5','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','EPL Dataset','EPL dataset contains tabular data ... ',0,'www.kaggle.com',NULL,'csv file format',0,'APPROVED','EPL'),('7d22f4c1-cb22-4855-a0ff-d160df7a1f07','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Cars Dataset','Cars dataset contains images of cars ... ',1,'www.kaggle.com',NULL,'jpg files format',0,'APPROVED','Vehicles'),('7eb7ee73-ea6e-44c7-a1a7-e526cdd4cd63','amey.kudari@students.iiit.ac.in','Refrence list','TEST DATASET COVID','This is the first description. This is the first description. This is the first description. This is the first description. This is the first description. This is the first description. This is the first description. This is the first description. This is the first description. This is the first description. This is the first description. ΠThis is the second description. This is the second description. This is the second description. This is the second description. This is the second description. This is the second description. This is the second description. This is the second description. This is the second description. ',1,'www.google.com',NULL,'CSV',0,'APPROVED','Covid'),('82785cbc-ec04-4c1b-98dc-6c3d28bfb5fe','belaal.ali@gmail.com','https://www.kaggle.com/datasets/nelgiriyewithana/countries-of-the-world-2023','Global Country Information Dataset 2023','This comprehensive dataset provides a wealth of information about all countries worldwide, covering a wide range of indicators and attributes. It encompasses demographic statistics, economic indicators, environmental factors, healthcare metrics, education statistics, and much more. With every country represented, this dataset offers a complete global perspective on various aspects of nations, enabling in-depth analyses and cross-country comparisons.Π With every country represented, this dataset offers a complete global perspective on various aspects of nations, enabling in-depth analyses and cross-country comparisons.',1,'https://www.kaggle.com/datasets/nelgiriyewithana/countries-of-the-world-2023',NULL,'CSV',0,'APPROVED','Stock Market'),('8636fa47-99ad-4371-a38d-e5c46618d4e0','amey.kudari2@students.iiit.ac.in','none','Amey 2','none',1,'none',NULL,'none',0,'APPROVED','asdf'),('89838ce2-22f2-49f0-ac12-b62939df4aa7','amey.kudari3@students.iiit.ac.in','-','Amey3 dataset','-',1,'-',NULL,'JSON',0,'APPROVED','asdf'),('8e0523b1-d441-4004-a1f1-050aac23e4ff','amey.kudari@students.iiit.ac.in','none','AMEY_TEST','This is a description.',1,'None',NULL,'CSV',0,'APPROVED','Covid'),('8e79e8e3-64a0-47ef-9ff3-75e4276d1c1e','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','MonkeyPox Data','Monkey data across the world, of all new infections, deaths and recoveries. Organized by day',1,'WHO',NULL,'csv',1,'APPROVED','Medical'),('900678bf-2d8a-42dc-bb8c-42662c691d85','amey.kudari@students.iiit.ac.in','asdf','asdff','asdf',1,'asdf',NULL,'asdf',0,'APPROVED','asdf'),('a1411307-4ecf-4a3d-8495-1393363814d3','amey.kudari@students.iiit.ac.in','ASDF','ADSF','ASDF',1,'ASDF',NULL,'ASDF',0,'APPROVED','Covid'),('a82825f9-bf37-4789-8687-a57f46c1b768','amey.kudari@students.iiit.ac.in','test','test','test',1,'test',NULL,'csv',0,'APPROVED','Covid'),('b015fad9-5abe-41fb-9b15-2b02fbcc93a5','amey.kudari@students.iiit.ac.in','test','test','test',1,'test',NULL,'csv',0,'APPROVED','Covid'),('b519f3ec-f13c-4716-971a-ff99dd1afa24','amey.kudari@students.iiit.ac.in','ASDF','AMEY','ADFASDFASDFΠQWERQWERQWER',1,'ADSFASDF',NULL,'CSV',0,'APPROVED','Covid'),('b73de476-e252-415b-861c-fcc4b552dc17','amey.kudari@students.iiit.ac.in','REF','TESTTEST','DESC',1,'NONE',NULL,'CSV',0,'APPROVED','Covid'),('b7e05b7e-05c6-4b8d-a842-e2dbdcbcf6c1','belaal.ali@gmail.com','https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/Y1BWBX','Covid-19 Policy Response Canadian tracker','A timeline of Covid-19 mitigation policy in Canada Covid-19 Policy Response Canadian tracker gathers information on public health measures for each province and territory in Canada. This information can assist in understanding government responses in every province across Canada. Public policies implemented by governments were recorded on a scale from 0 to 3 to reflect the degrees of restrictions in 3 different domains: school, workplace, and other, which are denoted as C1, C2, and C3 respectively. For full descriptions of the restrictions and their corresponding values refer to our Data Dictionary. ΠA timeline of Covid-19 mitigation policy in Canada Covid-19 Policy Response Canadian tracker gathers information on public health measures for each province and territory in Canada. This information can assist in understanding government responses in every province across Canada. Public policies implemented by governments were recorded on a scale from 0 to 3 to reflect the degrees of restrictions in 3 different domains: school, workplace, and other, which are denoted as C1, C2, and C3 respectively. For full descriptions of the restrictions and their corresponding values refer to our Data Dictionary. ',1,'https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/Y1BWBX',NULL,'CSV',0,'APPROVED','Medical'),('b9ff8e70-028b-4ba2-bc84-97c0ef20cbce','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Covid 19 USA','Covid 19 data of USA, of all new infections, deaths and recoveries. Organized by day',1,'WHO',NULL,'csv',1,'APPROVED','Covid'),('c597c178-64f7-4662-9232-1e47c2711a37','akshitsinha2801@gmail.com','A','A','A',1,'A',NULL,'CSV',0,'APPROVED','Covid'),('c881a4ac-8cfb-4f9a-829f-234015ae3110','amey.kudari@students.iiit.ac.in','none','TEST DATASET','THIS IS A DESC',1,'source',NULL,'CSV',0,'APPROVED','Covid'),('cf3d753f-e5ec-4990-b58f-d2efce400e44','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Amazon Rain Forest','Data of all known animals living in Amazon rain forest',1,'USAF',NULL,'csv',1,'PENDING','Wildlife'),('cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','MovieLens Dataset','MovieLens dataset is very popular dataset ... ',1,'www.kaggle.com',NULL,'png file format',0,'APPROVED','Movies'),('d7d8bdc3-e063-463d-be10-8f929c3160c3','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Amazon Forest','Data of all trees in amazon forest aged more than 100 years in the Amazon forest',1,'USAF',NULL,'csv',1,'APPROVED','Wildlife'),('d89bfa7c-9821-404b-8752-2122a348fe3a','dpa@gmail.com','NA','DPa dataset1','This is a DPa published dataset 1.',1,'NA',NULL,'csv',0,'APPROVED','Medical'),('daee1427-e5ce-489c-997d-81e80028c449','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Covid 19 India','Covid 19 data of India, of all new infections, deaths and recoveries. Organized by day',1,'WHO',NULL,'csv',1,'PENDING','Covid'),('e159954e-d777-4586-9f18-ba61ce1e0fc7','raghunath.iiit@gmail.com','NA','Dr. Raghunath Reddy','Sample test',1,'na',NULL,'csv',0,'APPROVED','Medical'),('e2e55a69-e814-4042-84c1-894940bcf087','amey.kudari@students.iiit.ac.in','asdf','Name','asdf',1,'asdf',NULL,'asdf',0,'APPROVED','asdf'),('eaaa6f65-4755-4dfe-87ff-6d51641aafaf','amey.kudari@students.iiit.ac.in','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723','Stock Market Nifty 50','Historic data of the stock market index nifty 50, and all stocks under nifty 50',1,'Yahoo Finance',NULL,'csv',1,'APPROVED','Stock Market'),('f7d83546-afff-4d6e-889d-4229b8fd8a53','amey.kudari@students.iiit.ac.in','ASDF','ADSF','ASDFΠqewrQEWRQWER',1,'source',NULL,'CSV',0,'APPROVED','Covid'),('f8c16077-dd1f-4085-a8af-d4ed4c3e7026','amey.kudari@students.iiit.ac.in','None','This dataset will be deleted','This is a dataset that will be deleted',1,'www.classified.com',NULL,'JSON',0,'APPROVED','Covid'),('fe7cb74c-d67e-4b2e-91f2-d48edd1f4053','pa@gmail.com','Na','d1','Sample',1,'NA',NULL,'pdf',0,'APPROVED','Medical');
/*!40000 ALTER TABLE `Dataset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DatasetGroups`
--

DROP TABLE IF EXISTS `DatasetGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DatasetGroups` (
  `group_id` varchar(255) NOT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DatasetGroups`
--

LOCK TABLES `DatasetGroups` WRITE;
/*!40000 ALTER TABLE `DatasetGroups` DISABLE KEYS */;
INSERT INTO `DatasetGroups` VALUES ('8ea36922-7c7a-48c3-8701-30c1f4199c2d','AMEY\'s GROUP','amey.kudari@students.iiit.ac.in','CREATOR'),('8ea36922-7c7a-48c3-8701-30c1f4199c2d','AMEY\'s GROUP','new.amey@gmail.com','MEMBER'),('df9978c2-4bb9-4bec-3ae7-8e1a6465acfe','ML Challenge','k.bhaskar306@gmail.com','CREATOR');
/*!40000 ALTER TABLE `DatasetGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DatasetVersion`
--

DROP TABLE IF EXISTS `DatasetVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DatasetVersion` (
  `dataset_version_id` varchar(255) NOT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `version_data` longblob,
  `version_data_format` varchar(255) DEFAULT NULL,
  `dataset_changes` longblob,
  `changes_format` varchar(255) DEFAULT NULL,
  `version_name` varchar(255) DEFAULT NULL,
  `abstract` text,
  `reference` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_edit` datetime DEFAULT NULL,
  `publication_names` text,
  `publication_links` text,
  PRIMARY KEY (`dataset_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DatasetVersion`
--

LOCK TABLES `DatasetVersion` WRITE;
/*!40000 ALTER TABLE `DatasetVersion` DISABLE KEYS */;
INSERT INTO `DatasetVersion` VALUES ('03b89f99-0b5a-4f51-ad27-37573c870931','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a',NULL,'JSON',NULL,'JSON','MovieLens 2.0','Newer movies from 2018 onwards are now included in the dataset','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('08e8f47d-a572-4c52-1b3e-788ed4e983c0','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','MARUTI','Historic data of MARUTI','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('15e9eef2-31ce-4812-8487-7f2082238bc7','7c758748-7c80-424e-bef9-dabfa0809cf5',NULL,'JSON',NULL,'JSON','EPL 1.0','EPL 2021-2022 matches included','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('1a5a91cd-2f3b-4124-83d1-4c2e9c71474a','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','INFY','Historic data of INFY','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('1dd90625-3fb5-4f9e-b22a-1d6cbafa6fc7','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','HINDALCO','Historic data of HINDALCO','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('249d157c-21cb-4ed2-8f46-f95614a93995','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','NTPC','Historic data of NTPC','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('505dfbe9-742c-46f8-82ad-324b34a77e0c','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TATAMOTORS','Historic data of TATAMOTORS','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('684ecc11-af05-408e-9d95-961c306f3995','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','HDFCBANK','Historic data of HDFCBANK','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('6d76b51c-6758-48dd-328c-88a767896280','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TCS','Historic data of TCS','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('7ff885d4-9597-437d-8169-caf4b68df9fd','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','HDFC','Historic data of HDFC','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('95f8dec2-96e7-4517-17a3-82374899f615','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','ICICIBANK','Historic data of ICICIBANK','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('a65bacae-534a-4b2f-92e4-b475fcaff163','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a',NULL,'JSON',NULL,'JSON','MovieLens 1.0','Newer movies from 2016 onwards are now included in the dataset','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('b33aff78-c31c-4a12-281e-53909a397e6d','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TATASTEEL','Historic data of TATASTEEL','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('c86ea044-749e-4d2b-0381-b1170fd19161','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','TITAN','Historic data of TITAN','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('d09a5b24-cad7-4db4-9cb9-355092e5d4c1','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','RELIANCE','Historic data of RELIANCE','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('d545db8b-cbd6-4b7d-b5c3-810a57ea6bd2','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','SBIN','Historic data of SBIN','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('d75d389c-b30b-4065-8663-669ece7511c6','7c758748-7c80-424e-bef9-dabfa0809cf5',NULL,'JSON',NULL,'JSON','EPL 2.0','EPL 2022-2023 matches included','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('e49f014d-a6b0-458f-1478-d7cad40a1014','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','BAJFINANCE','Historic data of BAJFINANCE','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('edade22d-b012-4b44-0cb6-d1058d30f562','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','M&M','Historic data of M&M','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('f9813aae-bbbf-437e-998d-e1a5177a49f3','cf8d7f83-0f7e-4f50-8ffd-aa63eb42782a',NULL,'JSON',NULL,'JSON','MovieLens 3.0','Newer movies from 2020 onwards are now included in the dataset','www.kaggle.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723'),('f9a1f390-9dfc-4827-b938-fbf757693737','eaaa6f65-4755-4dfe-87ff-6d51641aafaf',NULL,'CSV',NULL,'CSV','AXISBANK','Historic data of AXISBANK','www.yahoofinance.com','2022-06-14 06:14:27','2022-06-14 06:14:27','IEEE, ICAI','https://dl.acm.org/doi/abs/10.1145/2827872,https://dl.acm.org/doi/fullHtml/10.1145/3458723');
/*!40000 ALTER TABLE `DatasetVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DfsUser`
--

DROP TABLE IF EXISTS `DfsUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DfsUser` (
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) NOT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `user_role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DfsUser`
--

LOCK TABLES `DfsUser` WRITE;
/*!40000 ALTER TABLE `DfsUser` DISABLE KEYS */;
INSERT INTO `DfsUser` VALUES ('Akshit','Sinha','akshit','akshitsinha2801@gmail.com','IIIT H','Student','user, 1689038874514, hidden, {}'),('Amey','Kudari','amey','amey.kudari@students.iiit.ac.in','IIIT-H','software engineer','admin'),('Amey','Kudari','amey','amey.kudari2@students.iiit.ac.in','IIIT-H','software engineer','admin'),('Amey3','Kudari','amey','amey.kudari3@students.iiit.ac.in','IIIT-H','software engineer','admin'),('Amey4','Kudari','amey','amey.kudari4@students.iiit.ac.in','IIIT-H','software engineer','user'),('Anbumani','S','letmein','anbumani@iiit.ac.in','IIIT','Mobility','user, 1689314680781, hidden, {}'),('Vilal','Ali','123456','belaal.ali@gmail.com','IIIT','Sr. Developer','user, 1688985411405, hidden, {}'),('Deepika','N','ihub123','deepika.nanduri@ihub-data.iiit.ac.in','IHUB-DATA','ASE','user, 1689759514141, hidden, {}'),('DPa','dpa','dpa1234','dpa@gmail.com','dpainstitute','dpad','user, 1689673165611, hidden, {}'),('Dpb','dpb','dpb1234','dpb@gmail.com','dpbinstitute','dpbd','user, 1689673223671, hidden, {}'),('Ea','ea','ea1234','ea@gmail.com','eainstitute','ead','user, 1689673025908, hidden, {}'),('Eb','eb','eb1234','eb@gmail.com','eainstitute','ebd','user, 1689673078121, hidden, {}'),('Govind','Krishnan','MyInai88$','govind.krishnan@ihub-data.iiit.ac.in','INAI','Program Manager','user, 1689155479906, hidden, {}'),('Venugopal','Gundimeda','Genki@123','gundimeda.venugopal@ihub-data.iiit.ac.in','IHUB-DATA','architect','user, 1688365863217, hidden, {}'),('Bhaskar','K','123456','k.bhaskar306@gmail.com','IIITH','Engineer','User, 1689751495238, hidden, {}'),('Mohammed','Ibrahim','Mohammed#123','mohammed.ibrahim@ihub-data.iiit.ac.in','IIIT-Hyderabad','ML Engineer','User, 1689750673821, hidden, {}'),('new','amey','password','new.amey@gmail.com','IIIT--H','student','user, 1688100769857, hidden, {}'),('Deepika','Ratna','asd','nsavitha.sharma93@gmail.com','da','asd','User, 1689839249108, hidden, {}'),('N','Deepika','hub123','nssdeepika@gmail.com','sdf','sd','User, 1689838658088, hidden, {}'),('Pa','pa','pa1234','pa@gmail.com','painstitute','pad','user, 1689672762319, hidden, {}'),('Pb','pb','pb1234','pb@gmail.com','pbinstitute','pbd','user, 1689672852047, hidden, {}'),('Pc','pc','pc1234','pc@gmail.com','pcinstitute','pcd','user, 1689672894963, hidden, {}'),('Pd','pd','pd1234','pd@gmail.com','pdinstitute','pdd','user, 1689672932153, hidden, {}'),('Pe','pe','pe1234','pe@gmail.com','peinstitute','ped','user, 1689672981058, hidden, {}'),('Raghunath','Reddy','dfdev123$','raghunath.iiit@gmail.com','IIIT-H','SSE','user, 1688366499645, hidden, {}'),('Raghunath','Reddy','raghu123','raghunath.reddy@ihub-data.iiit.ac.in','IIIT-H','SSE','user, 1688105282174, hidden, {}'),('CMR Engineering Colleg','Reddy','cmr123','raghunathreddy@cmrec.ac.in','CMREC','Prof','User, 1689581533528, hidden, {}'),('Shaantanu','Kulkarni','shaan@123','shaantanu.kulkarni@students.iiit.ac.in','IIIT','developer','User, 1689256824943, hidden, {}'),('Shaan','Kulkarni','shaan@123','shaantanu2018@gmail.com','IIITH','software developer','User, 1689309258172, hidden, {}'),('User1','Lastname1','password','user1.lastname1@gmail.com','IIIT-H','normal user','user'),('Deepika','N','asd','yerramrajub3@gmail.com','as','asd','User, 1689839815299, hidden, {}');
/*!40000 ALTER TABLE `DfsUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Domain`
--

DROP TABLE IF EXISTS `Domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Domain` (
  `domain` varchar(255) NOT NULL,
  `publication_links` text,
  `publication_names` text,
  `publication_format` varchar(255) DEFAULT NULL,
  `abstract_a` text,
  `abstarct_b` text,
  `abstract_c` text,
  `last_addition` datetime DEFAULT NULL,
  PRIMARY KEY (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Domain`
--

LOCK TABLES `Domain` WRITE;
/*!40000 ALTER TABLE `Domain` DISABLE KEYS */;
INSERT INTO `Domain` VALUES ('Covid','Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('EPL','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Medical','Girish Varma, Anbumani Subramanian, Anoop Namboodiri, Manmohan Chandraker & C V Jawahar - IDD: A Dataset for Exploring Problems of Autonomous Navigation in Unconstrained Environments - IEEE Winter Conf. on Applications of Computer Vision (WACV 2019)','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Movies','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Stock Market','Absdf Qwer, Awer Sqer, Qsdf Qwer, S V Lajwer & S Q Awqer - SMD : Stock market historic data adjusted for stock splits','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Vehicles','','','','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27'),('Wildlife','Girish Varma, Anbumani Subramanian, Anoop Namboodiri, Manmohan Chandraker & C V Jawahar - IDD: A Dataset for Exploring Problems of Autonomous Navigation in Unconstrained Environments - IEEE Winter Conf. on Applications of Computer Vision (WACV 2019)','https://www.google.com/','PDF','While several datasets for autonomous navigation have become available in recent years, they have tended to focus on structured driving environments. This usually corresponds to well-delineated infrastructure such as lanes, a small number of well-defined categories for traffic participants, low variation in object or background appearance and strong adherence to traffic rules. We propose a novel dataset for road scene understanding in unstructured environments where the above assumptions are largely not satisfied. It consists of 10,000 images, finely annotated with 34 classes collected from 182 drive sequences on Indian roads. The label set is expanded in comparison to popular benchmarks such as Cityscapes, to account for new classes.','The dataset consists of images obtained from a front facing camera attached to a car. The car was driven around Hyderabad, Bangalore cities and their outskirts. The images are mostly of 1080p resolution, but there is also some images with 720p and other resolutions.','','2022-06-14 06:14:27');
/*!40000 ALTER TABLE `Domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Files`
--

DROP TABLE IF EXISTS `Files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Files` (
  `upfilename` varchar(255) NOT NULL,
  `upfilenameMD` varchar(255) DEFAULT NULL,
  `filetype` varchar(255) DEFAULT NULL,
  `filesize` bigint DEFAULT NULL,
  `database_id` varchar(255) DEFAULT NULL,
  `databaseVersion_id` varchar(255) DEFAULT NULL,
  `comments` text,
  `version_name` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `created_date` varchar(255) DEFAULT NULL,
  `last_edit` varchar(255) DEFAULT NULL,
  `publication_names` text,
  `publication_links` text,
  `verification` varchar(255) DEFAULT NULL,
  `public` varchar(255) DEFAULT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `additional` text,
  PRIMARY KEY (`upfilename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Files`
--

LOCK TABLES `Files` WRITE;
/*!40000 ALTER TABLE `Files` DISABLE KEYS */;
INSERT INTO `Files` VALUES ('1688101097649_a.0.add.htEm','1688101107412_fixed.html','TEST COVID',3146949,'2328710d-e0c6-4fa8-b28a-265b4b6fa7d1','1-1-1','This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset.ΠThis is the second para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset.ΠThis is the third para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset. This is the first para, it is a description to a test dataset.','TEST COVID','none','1687996800000','1688101137959','NONE','None','rejected','public','amey.kudari@students.iiit.ac.in','1688101124949_html_not_getting_rendered_16080|||||1688101133389_initialHTMLimg_and_nbsp.html_14746'),('1688227952056_a.0.add.htEm','1688227961099_initialHTML.html','CSV',3146949,'7eb7ee73-ea6e-44c7-a1a7-e526cdd4cd63','1-1-1','This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph. This is the first paragraph.','TEST COVID VERSION','www.google.com','1685577600000','1688227984899','covid_data','www.covid_data.com','verified','public','amey.kudari@students.iiit.ac.in','1688227968867_tmp1.html_18072|||||1688227977526_beer.png_12759'),('1688981454282_datafoundation-dev.iiit.ac.in.har','1688981458482_datafoundation-dev.iiit.ac.in.har','CSV',13441,'b73de476-e252-415b-861c-fcc4b552dc17','1-1-1','DESC','NAME','REF','944352000000','1688981936244','CSV','PUB','rejected','public','amey.kudari@students.iiit.ac.in','1688981934986_datafoundation-dev.iiit.ac.in.har_13441'),('1688982649626_datafoundation-dev.iiit.ac.in.har','1688982654229_datafoundation-dev.iiit.ac.in.har','ADSF',13441,'a1411307-4ecf-4a3d-8495-1393363814d3','1-1-1','ASDF','123','123','944352000000','1688982677566','CSV','none','verified','public','amey.kudari@students.iiit.ac.in','1688982660802_ibt-paper-edition-practice-test (1).zip_30235613'),('1688982709061_datafoundation-dev.iiit.ac.in.har','1688982713757_datafoundation-dev.iiit.ac.in.har','ADFS',13441,'2328710d-e0c6-4fa8-b28a-265b4b6fa7d1','1-1-1','DESC','VERSION','REF','-55858118400000','1688982715450','CSV','PUB_LINK','unverified','public','amey.kudari@students.iiit.ac.in',''),('1688990019329_EBHASHA-SETU-LANGUAGE-SERVICES-PRIVATE-LIMITED_shipping.zip','1688990023002_1676843260975_README.md','CSV',1561,'2ddff60f-b79d-475c-b1ec-1cbd01d2017d','1','The circadian rhythm of gene expression in mesenchymal stem cells. The circadian rhythm of gene expression in mesenchymal stem cells.ΠThe circadian rhythm of gene expression in mesenchymal stem cells. The circadian rhythm of gene expression in mesenchymal stem cells. The circadian rhythm of gene expression in mesenchymal stem cells.','X1.0','https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/DWOLNR','1688947200000','1688990027941','https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/DWOLNR','https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/DWOLNR','unverified','public','belaal.ali@gmail.com','1688990024435_TimeZone.xlsx_48398'),('1688990409459_EBHASHA-SETU-LANGUAGE-SERVICES-PRIVATE-LIMITED_shipping.zip','1688990410939_1676843260975_README.md','CSV',1561,'b7e05b7e-05c6-4b8d-a842-e2dbdcbcf6c1','1','A timeline of Covid-19 mitigation policy in Canada Covid-19 Policy Response Canadian tracker gathers information on public health measures for each province and territory in Canada. This information can assist in understanding government responses in every province across Canada. Public policies implemented by governments were recorded on a scale from 0 to 3 to reflect the degrees of restrictions in 3 different domains: school, workplace, and other, which are denoted as C1, C2, and C3 respectively. For full descriptions of the restrictions and their corresponding values refer to our Data Dictionary.ΠA timeline of Covid-19 mitigation policy in Canada Covid-19 Policy Response Canadian tracker gathers information on public health measures for each province and territory in Canada. This information can assist in understanding government responses in every province across Canada. Public policies implemented by governments were recorded on a scale from 0 to 3 to reflect the degrees of restrictions in 3 different domains: school, workplace, and other, which are denoted as C1, C2, and C3 respectively. For full descriptions of the restrictions and their corresponding values refer to our Data Dictionary.ΠA timeline of Covid-19 mitigation policy in Canada Covid-19 Policy Response Canadian tracker gathers information on public health measures for each province and territory in Canada. This information can assist in understanding government responses in every province across Canada. Public policies implemented by governments were recorded on a scale from 0 to 3 to reflect the degrees of restrictions in 3 different domains: school, workplace, and other, which are denoted as C1, C2, and C3 respectively. For full descriptions of the restrictions and their corresponding values refer to our Data Dictionary.','Y1.0','https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/Y1BWBX','1689033600000','1688990412764','Mitigation Implementations Timelines reports timelines of restrictions for every province/territory.','Mitigation Implementations Timelines reports timelines of restrictions for every province/territory.','unverified','private','belaal.ali@gmail.com',''),('1689005772167_convex optimization-book.pdf','1689005841746_readme.txt','PDF',7187113,'2198225a-e2d4-45e7-ac68-301e86b6fb9d','1-0-0','Convex  Optimization Book','Convex Optimization V1.0','https://web.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf','1688947200000','1689005845876','Convex Optimization by Boyd','https://web.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf','verified','public','gundimeda.venugopal@ihub-data.iiit.ac.in',''),('1689244638957_iraste_nxt_casdms.csv','1689244642842_readme.txt','csv',3368006,'3a8ad838-3515-463a-9890-56cab8a8cf36','1','test','1','1','1689206400000','1689244645054','none','none','verified','public','govind.krishnan@ihub-data.iiit.ac.in',''),('1689303796541_Aegifi.png','1689303802652_Aegifi.png','CSV',8415,'c597c178-64f7-4662-9232-1e47c2711a37','1-1-1','this','v0','this','1689033600000','1689303803440','a','a','verified','public','akshitsinha2801@gmail.com',''),('1689303946101_Aegifi.png','1689303950340_Aegifi.png','CSV',8415,'6a7d99df-37ea-4ca8-8586-07deb893e678','1-1-1','this','v1','tjis','1688947200000','1689303951181','this','this','verified','public','akshitsinha2801@gmail.com',''),('1689310368258_251a9d46-76de-404b-8371-7a30ac92d550.pdf','1689310378678_2023 Recruitments - OSDG(1-34).xlsx','CSV',49968,'6a7d99df-37ea-4ca8-8586-07deb893e678','2-2-2','t','v12','t','1689206400000','1689310386783','t','t','verified','public','akshitsinha2801@gmail.com','1689310384733_IIIT-H.pdf_191745'),('1689398492310_BTech_EEE_Syllabus_2018.pdf','1689398494706_readme.txt','pdf',1824292,'0b412fb6-7993-44fb-ad5f-1e2a3c776c6b','1-1-1','This is a sample datatset','v1','NA','1689379200000','1689398510781','NA','NA','rejected','private','raghunath.iiit@gmail.com',''),('1689431599599_html.html','1689431606348_html.html','CSV',14973,'73d30de2-e291-4981-957e-54beeb0ec94d','1-1-1','This is a file','v1','none','1670198400000','1689431617471','CSV','none','verified','public','amey.kudari@students.iiit.ac.in','1689431615887_html.html_14973'),('1689676136640_Flowdb.zip','1689676141134_Flowdbreadme.txt','csv',40239479,'d89bfa7c-9821-404b-8752-2122a348fe3a','1-0-1','FlowDB is a large scale river, precipitation, and temperature dataset for river flow and flash flood forecasting. The files provided here are a small subset of rivers of the much larger FlowDB datatset. The rivers and streams selected here form a new benchmark for multivariate time series forecasting. We selected these river/streams from the larger dataset due to their uniqueness (well representing different regions of the United States) as well as (for some) their propensity to have flash floods. Altogether these streams/rivers form a challenging benchmark for multivariate time series forecasting models due to their variability and different temporal nature. If you would like to see the full FlowDB dataset of 9,000+ rivers please follow this link.','v1','https://www.kaggle.com/datasets/isaacmg/flowdb-sample','1689638400000','1689676154304','NA','https://www.kaggle.com/datasets/isaacmg/flowdb-sample','verified','public','dpa@gmail.com',''),('1689768909442_latest_dump.sql','1689768912965_1676843260975_README.md','CSV',66080,'82785cbc-ec04-4c1b-98dc-6c3d28bfb5fe','1','This comprehensive dataset provides a wealth of information about all countries worldwide, covering a wide range of indicators and attributes. It encompasses demographic statistics, economic indicators, environmental factors, healthcare metrics, education statistics, and much more.ΠWith every country represented, this dataset offers a complete global perspective on various aspects of nations, enabling in-depth analyses and cross-country comparisons.','Density (P/Km2)','https://www.kaggle.com/datasets/nelgiriyewithana/countries-of-the-world-2023','1689724800000','1689768914930','N/A','https://www.kaggle.com/datasets/nelgiriyewithana/countries-of-the-world-2023','unverified','public','belaal.ali@gmail.com',''),('1689838250696_Endorsement_Form.pdf','1689838253354_readme.txt','pdf',89491,'fe7cb74c-d67e-4b2e-91f2-d48edd1f4053','1','sample','v1','na','1689811200000','1689838280430','na','na','verified','public','pa@gmail.com','1689838276892_readme.txt_27'),('1689840257694_car sales.zip','1689840259481_readme.txt','pdf',89946967,'43c25436-9e97-413b-ad59-341284830bfc','1','Sample dataset','v1','NA','1689811200000','1689840266377','NA','NA','verified','public','pa@gmail.com','');
/*!40000 ALTER TABLE `Files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ModelRequests`
--

DROP TABLE IF EXISTS `ModelRequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ModelRequests` (
  `model_id` varchar(255) DEFAULT NULL,
  `request_id` varchar(255) NOT NULL,
  `request_status` varchar(255) DEFAULT NULL,
  `request_for` varchar(255) DEFAULT NULL,
  `requester_id` varchar(255) DEFAULT NULL,
  `requestee_id` varchar(255) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ModelRequests`
--

LOCK TABLES `ModelRequests` WRITE;
/*!40000 ALTER TABLE `ModelRequests` DISABLE KEYS */;
INSERT INTO `ModelRequests` VALUES ('ASDF','ASDF1234','accepted','write','amey.kudari@students.iiit.ac.in','amey.kudari@students.iiit.ac.in',NULL);
/*!40000 ALTER TABLE `ModelRequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Models`
--

DROP TABLE IF EXISTS `Models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Models` (
  `dataset_version_id` varchar(255) DEFAULT NULL,
  `dataset_id` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `model_id` varchar(255) NOT NULL,
  `model_name` varchar(255) DEFAULT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  `author_id` varchar(255) DEFAULT NULL,
  `author_name` varchar(255) DEFAULT NULL,
  `authors_names` text,
  `authors_ids` text,
  `created_datetime` varchar(255) DEFAULT NULL,
  `last_updated` varchar(255) DEFAULT NULL,
  `updates` int DEFAULT NULL,
  `jsondata` longtext,
  `group_read` tinyint(1) DEFAULT '0',
  `group_write` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Models`
--

LOCK TABLES `Models` WRITE;
/*!40000 ALTER TABLE `Models` DISABLE KEYS */;
INSERT INTO `Models` VALUES ('ASDF','ASDF','ASDF','ASDF','ASDF','ASDF','amey.kudari@students.iiit.ac.in','Amey',', Amey',', amey.kudari@students.iiit.ac.in','1663502724962','1673040502915',2,'1673040498430_Untitled.ipynb',0,0);
/*!40000 ALTER TABLE `Models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Requests`
--

DROP TABLE IF EXISTS `Requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Requests` (
  `upfilename` varchar(255) NOT NULL,
  `upfilenameMD` varchar(255) DEFAULT NULL,
  `requester` varchar(255) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `stat` varchar(255) DEFAULT NULL,
  `comment` text,
  `av1` text,
  PRIMARY KEY (`upfilename`,`requester`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Requests`
--

LOCK TABLES `Requests` WRITE;
/*!40000 ALTER TABLE `Requests` DISABLE KEYS */;
INSERT INTO `Requests` VALUES ('1659171950338_uploaderPage.js','1659171953324_Screenshot from 2022-07-26 22-18-20.png','amey.kudari@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','accepted','asdfasdf\nqwerqwer qwe\nasdf','BLANK'),('1659177934815_back1.jpg','1659177936601_uploaderPage.js','amey.kudari@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','requested','asdf','BLANK'),('1659184056031_changes.zip','1659184061702_readme.md','amey.kudari2@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','rejected','I am amey 2, I want access to this database.','BLANK'),('1660549592494_symbols.json','1660549621737_dfsdata.sql','amey.kudari@students.iiit.ac.in','amey.kudari2@students.iiit.ac.in','rejected','I want access to this database.','BLANK'),('1660623210881_tmp.json','1660623202595_tmp.md','amey.kudari@students.iiit.ac.in','amey.kudari3@students.iiit.ac.in','accepted','I am Amey, I want access to the file. ','BLANK'),('1660629925559_tmp.json','1660629949387_tmp.md','amey.kudari4@students.iiit.ac.in','amey.kudari@students.iiit.ac.in','accepted','I am Amey4, I want access to this dataset because I want to do <abcc> research work on it','BLANK'),('1688101097649_a.0.add.htEm','1688101107412_fixed.html','8ea36922-7c7a-48c3-8701-30c1f4199c2d','amey.kudari@students.iiit.ac.in','accepted','Self Assigned','BLANK');
/*!40000 ALTER TABLE `Requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tnc`
--

DROP TABLE IF EXISTS `Tnc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Tnc` (
  `target_id` varchar(255) NOT NULL,
  `dataset_level` enum('DATASET','FILE') NOT NULL,
  `md_data` longtext,
  PRIMARY KEY (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tnc`
--

LOCK TABLES `Tnc` WRITE;
/*!40000 ALTER TABLE `Tnc` DISABLE KEYS */;
INSERT INTO `Tnc` VALUES ('1659171950338_uploaderPage.js','DATASET','These are the terms and conditions\n- asdfasdfasdfasd\n- qewrk jqwelkrj asopdfk jaspofi qwjerfqw er\n- qwerqwer qwer qwerqwer qwer qwer\n- asdfasdfzxcvqwerqwerqewrqwer\n- aweqrasdfasdfasdf\n- qewrqwerqewrqwerqwerqwerqwerqewrerqw\n### This is another heading\nThis is text under that other heading\n#### YET ANOTHER HEADING!!!!\nand a little more text :) all formats supported'),('1687716617708_html_not_getting_rendered','DATASET','THIS IS SAMPLE TNC'),('1688050842392_html_not_getting_rendered','DATASET','THIS IS A NEW TNC'),('1688051529640_html_not_getting_rendered','DATASET','THIS IS TNC!!! :D'),('1688100444629_a.0.add.htEm','DATASET','This is a sample tnc\n---\nWith great power, comes great responsiblity. Use this dataset carefully.'),('1688101097649_a.0.add.htEm','DATASET','# **Sample Data Use Agreement (DUA)**\n\n*Note: This is a sample DUA for datasets that have de-identified human subject data*\n\nThis is an agreement (“Agreement”) between you, the downloader (“Downloader”), and the owner of the materials (“Publisher”) governing the use of the materials (“Materials”) to be downloaded.\n\n## I. Acceptance of this Agreement\n\nBy downloading or otherwise accessing the Materials, Downloader represents his/her acceptance of the terms of this Agreement.\n\n## II. Modification of this Agreement\n\nPublishers may modify the terms of this Agreement at any time. However, any modifications to this Agreement will only be effective for downloads subsequent to such modification. No modifications will supersede any previous terms that were in effect at the time of the Downloader’s download.\n\n## III. Use of the Materials\n\nUse of the Materials include but are not limited to:\n\n- Viewing parts or the whole of the content included in the Materials\n- Comparing data or content from the Materials with data or content in other Materials\n- Verifying research results with the content included in the Materials\n- Extracting and/or appropriating any part of the content included in the Materials for use in other projects, publications, research, or other related work products.\n\n## Representations\n\n**A.** In Use of the Materials, Downloader represents that:\n\n- Downloader is not bound by any pre-existing legal obligations or other applicable laws that prevent Downloader from downloading or using the Materials.\n- Downloader will not use the Materials in any way prohibited by applicable laws.\n- Downloader has no knowledge of and will therefore not be responsible for any restrictions regarding the use of Materials beyond what is described in this Agreement.\n- Downloader has no knowledge of and will therefore not be responsible for any inaccuracies and any other such problems with regards to the content of the Materials and the accompanying citation information.\n\n**B.** Restrictions In his/her Use of the Materials, Downloaders cannot:\n\n- Obtain information from the Materials that results in Downloader or any third party(ies) directly or indirectly identifying any research subjects with the aid of other information acquired elsewhere.\n- Produce connections or links among the information included in Publisher’s datasets (including information in the Materials), or between the information included in Publisher’s datasets (including information in the Materials) and other third-party information that could be used to identify any individuals or organizations, not limited to research subjects.\n- Extract information from the Materials that could aid Downloader in gaining knowledge about or obtaining any means of contacting any subjects already known to Downloader.\n\n## IV. Representations and Warranties\n\n**PUBLISHER REPRESENTS** THAT PUBLISHER HAS ALL RIGHTS REQUIRED TO MAKE AVAILABLE AND DISTRIBUTE THE MATERIALS. EXCEPT FOR SUCH REPRESENTATION, THE MATERIALS IS PROVIDED “AS IS” AND “AS AVAILABLE” AND WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A PARTICULAR PURPOSE, AND ANY WARRANTIES IMPLIED BY ANY COURSE OF PERFORMANCE OR USAGE OF TRADE, ALL OF WHICH ARE EXPRESSLY DISCLAIMED.\n\nWITHOUT LIMITING THE FOREGOING, PUBLISHER DOES NOT WARRANT THAT:\n\n(A) THE MATERIALS ARE ACCURATE, COMPLETE, RELIABLE OR CORRECT\n(B) THE MATERIALS FILES WILL BE SECURE\n(C) THE MATERIALS WILL BE AVAILABLE AT ANY PARTICULAR TIME OR LOCATION\n(D) ANY DEFECTS OR ERRORS WILL BE CORRECTED\n(E) THE MATERIALS AND ACCOMPANYING FILES ARE FREE OF HARMFUL COMPONENTS OR\n(F) THE RESULTS OF USING THE MATERIALS WILL MEET DOWNLOADER’S REQUIREMENTS. DOWNLOADER’S USE OF THE MATERIALS IS SOLELY AT DOWNLOADER’S OWN RISK.\n\n## V. Limitation of Liability\n\nIN NO EVENT SHALL PUBLISHER BE LIABLE UNDER CONTRACT, TORT, STRICT LIABILITY, NEGLIGENCE, OR ANY OTHER LEGAL THEORY WITH RESPECT TO THE MATERIALS:\n\n(I) FOR ANY DIRECT DAMAGES, OR\n(II) FOR ANY LOST PROFITS OR SPECIAL, INDIRECT, INCIDENTAL, PUNITIVE, OR CONSEQUENTIAL DAMAGES OF ANY KIND WHATSOEVER.\n\n## VI. Indemnification\n\nDownloader will indemnify and hold Publisher harmless from and against any and all loss, cost, expense, liability, or damage, including, without limitation, all reasonable attorneys’ fees and court costs, arising from the:\n\n(i) Downloader’s misuse of the Materials\n(ii) Downloader’s violation of the terms of this Agreement or\n(iii) infringement by Downloader or any third party of any intellectual property or other right of any person or entity contained in the Materials. Such losses, costs, expenses, damages, or liabilities shall include, without limitation, all actual, general, special, and consequential damages.\n\n## VII. Dispute Resolution\n\nDownloader and Publisher agree that any cause of action arising out of or related to the download or use of the Materials must commence within one (1) year after the cause of action arose otherwise, such cause of action is permanently barred.\n\nThis Agreement shall be governed by and interpreted in accordance with the Indian Information Technology Act (excluding the conflict of laws rules thereof). All disputes under this Agreement will be resolved in the applicable government laws. Downloader consents to the jurisdiction of such courts and waives any jurisdictional or venue defenses otherwise available.\n\n## VIII. Integration and Severability\n\nThis Agreement represents the entire agreement between Downloader and Publisher with respect to the downloading and use of the Materials, and supersedes all prior or contemporaneous communications and proposals (whether oral, written, or electronic) between Downloader and Publisher with respect to downloading or using the Materials. If any provision of this Agreement is found to be unenforceable or invalid, that provision will be limited or eliminated to the minimum extent necessary so that the Agreement will otherwise remain in full force and effect and enforceable.\n\n## IX. Miscellaneous\n\nPublisher may assign, transfer, or delegate any of its rights and obligations hereunder without consent. No agency, partnership, joint venture, or employment relationship is created as a result of the Agreement, and neither party has any authority of any kind to bind the other in any respect outside of the terms described within this Agreement. In any action or proceeding to enforce rights under the Agreement, the prevailing party will be entitled to recover costs and attorneys’ fees.'),('1688227952056_a.0.add.htEm','DATASET','### TNC\nThe right to use the disk shall expire either when the user destroys the Disk or software, or when any of the terms of this Agreement are violated and the Licensors exercise the option to revoke the license to use the Disk or software. The terms and conditions hereof apply to all subsequent users and owners as well as to the original purchaser. The use of oil company logos in the display are for your information and convenience, and in no way implies any sponsorship, approval or endorsement of t'),('1689838250696_Endorsement_Form.pdf','DATASET','*Note: This is a sample DUA for datasets that have de-identified human subject data\n\nThis is an agreement (“Agreement”) between you the downloader (“Downloader”) and the owner of the materials (“Publisher”) governing the use of the materials (“Materials”) to be downloaded.\n\nI. Acceptance of this Agreement\n\nBy downloading or otherwise accessing the Materials, Downloader represents his/her acceptance of the terms of this Agreement.\n\nII. Modification of this Agreement\n\nPublishers may modify the terms of this Agreement at any time. However, any modifications to this Agreement will only be effective for downloads subsequent to such modification. No modifications will supersede any previous terms that were in effect at the time of the Downloader’s download.\n\nIII. Use of the Materials\n\nUse of the Materials include but are not limited to viewing parts or the whole of the content included in the Materials; comparing data or content from the Materials with data or content in other Materials; verifying research results with the content included in the Materials; and extracting and/or appropriating any part of the content included in the Materials for use in other projects, publications, research, or other related work products.\n\nRepresentations\n\nA. In Use of the Materials, Downloader represents that:\nDownloader is not bound by any pre-existing legal obligations or other applicable laws that prevent Downloader from downloading or using the Materials;\nDownloader will not use the Materials in any way prohibited by applicable laws;\nDownloader has no knowledge of and will therefore not be responsible for any restrictions regarding the use of Materials beyond what is described in this Agreement; and Downloader has no knowledge of and will therefore not be responsible for any inaccuracies and any other such problems with regards to the content of the Materials and the accompanying citation information.\n\nB. Restrictions In his/her Use of the Materials, Downloaders cannot obtain information from the Materials that results in Downloader or any third party(ies) directly or indirectly identifying any research subjects with the aid of other information acquired elsewhere;\nproduce connections or links among the information included in Publisher’s datasets (including information in the Materials), or between the information included in Publisher’s datasets (including information in the Materials) and other third-party information that could be used to identify any individuals or organizations, not limited to research subjects; and extract information from the Materials that could aid Downloader in gaining knowledge about or obtaining any means of contacting any subjects already known to Downloader.\n\nIV. Representations and Warranties\n\nPUBLISHER REPRESENTS THAT PUBLISHER HAS ALL RIGHTS REQUIRED TO MAKE AVAILABLE AND DISTRIBUTE THE MATERIALS. EXCEPT FOR SUCH REPRESENTATION, THE MATERIALS IS PROVIDED “AS IS” AND “AS AVAILABLE” AND WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, AND ANY WARRANTIES IMPLIED BY ANY COURSE OF PERFORMANCE OR USAGE OF TRADE, ALL OF WHICH ARE EXPRESSLY DISCLAIMED.\n\nWITHOUT LIMITING THE FOREGOING, PUBLISHER DOES NOT WARRANT THAT: (A) THE MATERIALS ARE ACCURATE, COMPLETE, RELIABLE OR CORRECT; (B) THE MATERIALS FILES WILL BE SECURE ; (C) THE MATERIALS WILL BE AVAILABLE AT ANY PARTICULAR TIME OR LOCATION; (D) ANY DEFECTS OR ERRORS WILL BE CORRECTED; (E) THE MATERIALS AND ACCOMPANYING FILES ARE FREE OF HARMFUL COMPONENTS; OR (F) THE RESULTS OF USING THE MATERIALS WILL MEET DOWNLOADER’S REQUIREMENTS. DOWNLOADER’S USE OF THE MATERIALS IS SOLELY AT DOWNLOADER’S OWN RISK.\n\nV. Limitation of Liability\n\nIN NO EVENT SHALL PUBLISHER BE LIABLE UNDER CONTRACT, TORT, STRICT LIABILITY, NEGLIGENCE OR ANY OTHER LEGAL THEORY WITH RESPECT TO THE MATERIALS (I) FOR ANY DIRECT DAMAGES, OR (II) FOR ANY LOST PROFITS OR SPECIAL, INDIRECT, INCIDENTAL, PUNITIVE, OR CONSEQUENTIAL DAMAGES OF ANY KIND WHATSOEVER.\n\nVI. Indemnification\n\nDownloader will indemnify and hold Publisher harmless from and against any and all loss, cost, expense, liability, or damage, including, without limitation, all reasonable attorneys’ fees and court costs, arising from the i) Downloader’s misuse of the Materials; (ii) Downloader’s violation of the terms of this Agreement; or (iii) infringement by Downloader or any third party of any intellectual property or other right of any person or entity contained in the Materials. Such losses, costs, expenses, damages, or liabilities shall include, without limitation, all actual, general, special, and consequential damages.\n\nVII. Dispute Resolution\n\nDownloader and Publisher agree that any cause of action arising out of or related to the download or use of the Materials must commence within one (1) year after the cause of action arose; otherwise, such cause of action is permanently barred.\n\nThis Agreement shall be governed by and interpreted in accordance with the Indian Information Technology Act (excluding the conflict of laws rules thereof). All disputes under this Agreement will be resolved in the applicable government laws. Downloader consents to the jurisdiction of such courts and waives any jurisdictional or venue defenses otherwise available.\n\nVIII. Integration and Severability\n\nThis Agreement represents the entire agreement between Downloader and Publisher with respect to the downloading and use of the Materials, and supersedes all prior or contemporaneous communications and proposals (whether oral, written or electronic) between Downloader and Publisher with respect to downloading or using the Materials. If any provision of this Agreement is found to be unenforceable or invalid, that provision will be limited or eliminated to the minimum extent necessary so that the Agreement will otherwise remain in full force and effect and enforceable.\n\nIX. Miscellaneous\n\nPublisher may assign, transfer or delegate any of its rights and obligations hereunder without consent. No agency, partnership, joint venture, or employment relationship is created as a result of the Agreement and neither party has any authority of any kind to bind the other in any respect outside of the terms described within this Agreement. In any action or proceeding to enforce rights under the Agreement, the prevailing party will be entitled to recover costs and attorneys’ fees'),('1689840257694_car sales.zip','DATASET','*Note: This is a sample DUA for datasets that have de-identified human subject data\n\nThis is an agreement (“Agreement”) between you the downloader (“Downloader”) and the owner of the materials (“Publisher”) governing the use of the materials (“Materials”) to be downloaded.\n\nI. Acceptance of this Agreement\n\nBy downloading or otherwise accessing the Materials, Downloader represents his/her acceptance of the terms of this Agreement.\n\nII. Modification of this Agreement\n\nPublishers may modify the terms of this Agreement at any time. However, any modifications to this Agreement will only be effective for downloads subsequent to such modification. No modifications will supersede any previous terms that were in effect at the time of the Downloader’s download.\n\nIII. Use of the Materials\n\nUse of the Materials include but are not limited to viewing parts or the whole of the content included in the Materials; comparing data or content from the Materials with data or content in other Materials; verifying research results with the content included in the Materials; and extracting and/or appropriating any part of the content included in the Materials for use in other projects, publications, research, or other related work products.\n\nRepresentations\n\nA. In Use of the Materials, Downloader represents that:\nDownloader is not bound by any pre-existing legal obligations or other applicable laws that prevent Downloader from downloading or using the Materials;\nDownloader will not use the Materials in any way prohibited by applicable laws;\nDownloader has no knowledge of and will therefore not be responsible for any restrictions regarding the use of Materials beyond what is described in this Agreement; and Downloader has no knowledge of and will therefore not be responsible for any inaccuracies and any other such problems with regards to the content of the Materials and the accompanying citation information.\n\nB. Restrictions In his/her Use of the Materials, Downloaders cannot obtain information from the Materials that results in Downloader or any third party(ies) directly or indirectly identifying any research subjects with the aid of other information acquired elsewhere;\nproduce connections or links among the information included in Publisher’s datasets (including information in the Materials), or between the information included in Publisher’s datasets (including information in the Materials) and other third-party information that could be used to identify any individuals or organizations, not limited to research subjects; and extract information from the Materials that could aid Downloader in gaining knowledge about or obtaining any means of contacting any subjects already known to Downloader.\n\nIV. Representations and Warranties\n\nPUBLISHER REPRESENTS THAT PUBLISHER HAS ALL RIGHTS REQUIRED TO MAKE AVAILABLE AND DISTRIBUTE THE MATERIALS. EXCEPT FOR SUCH REPRESENTATION, THE MATERIALS IS PROVIDED “AS IS” AND “AS AVAILABLE” AND WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, AND ANY WARRANTIES IMPLIED BY ANY COURSE OF PERFORMANCE OR USAGE OF TRADE, ALL OF WHICH ARE EXPRESSLY DISCLAIMED.\n\nWITHOUT LIMITING THE FOREGOING, PUBLISHER DOES NOT WARRANT THAT: (A) THE MATERIALS ARE ACCURATE, COMPLETE, RELIABLE OR CORRECT; (B) THE MATERIALS FILES WILL BE SECURE ; (C) THE MATERIALS WILL BE AVAILABLE AT ANY PARTICULAR TIME OR LOCATION; (D) ANY DEFECTS OR ERRORS WILL BE CORRECTED; (E) THE MATERIALS AND ACCOMPANYING FILES ARE FREE OF HARMFUL COMPONENTS; OR (F) THE RESULTS OF USING THE MATERIALS WILL MEET DOWNLOADER’S REQUIREMENTS. DOWNLOADER’S USE OF THE MATERIALS IS SOLELY AT DOWNLOADER’S OWN RISK.\n\nV. Limitation of Liability\n\nIN NO EVENT SHALL PUBLISHER BE LIABLE UNDER CONTRACT, TORT, STRICT LIABILITY, NEGLIGENCE OR ANY OTHER LEGAL THEORY WITH RESPECT TO THE MATERIALS (I) FOR ANY DIRECT DAMAGES, OR (II) FOR ANY LOST PROFITS OR SPECIAL, INDIRECT, INCIDENTAL, PUNITIVE, OR CONSEQUENTIAL DAMAGES OF ANY KIND WHATSOEVER.\n\nVI. Indemnification\n\nDownloader will indemnify and hold Publisher harmless from and against any and all loss, cost, expense, liability, or damage, including, without limitation, all reasonable attorneys’ fees and court costs, arising from the i) Downloader’s misuse of the Materials; (ii) Downloader’s violation of the terms of this Agreement; or (iii) infringement by Downloader or any third party of any intellectual property or other right of any person or entity contained in the Materials. Such losses, costs, expenses, damages, or liabilities shall include, without limitation, all actual, general, special, and consequential damages.\n\nVII. Dispute Resolution\n\nDownloader and Publisher agree that any cause of action arising out of or related to the download or use of the Materials must commence within one (1) year after the cause of action arose; otherwise, such cause of action is permanently barred.\n\nThis Agreement shall be governed by and interpreted in accordance with the Indian Information Technology Act (excluding the conflict of laws rules thereof). All disputes under this Agreement will be resolved in the applicable government laws. Downloader consents to the jurisdiction of such courts and waives any jurisdictional or venue defenses otherwise available.\n\nVIII. Integration and Severability\n\nThis Agreement represents the entire agreement between Downloader and Publisher with respect to the downloading and use of the Materials, and supersedes all prior or contemporaneous communications and proposals (whether oral, written or electronic) between Downloader and Publisher with respect to downloading or using the Materials. If any provision of this Agreement is found to be unenforceable or invalid, that provision will be limited or eliminated to the minimum extent necessary so that the Agreement will otherwise remain in full force and effect and enforceable.\n\nIX. Miscellaneous\n\nPublisher may assign, transfer or delegate any of its rights and obligations hereunder without consent. No agency, partnership, joint venture, or employment relationship is created as a result of the Agreement and neither party has any authority of any kind to bind the other in any respect outside of the terms described within this Agreement. In any action or proceeding to enforce rights under the Agreement, the prevailing party will be entitled to recover costs and attorneys’ fees'),('eaaa6f65-4755-4dfe-87ff-6d51641aafaf','DATASET','1. ksjdnflkajs');
/*!40000 ALTER TABLE `Tnc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `dfs_user_id` varchar(255) NOT NULL,
  `dfs_user_name` varchar(255) DEFAULT NULL,
  `dfs_user_role` varchar(255) DEFAULT NULL,
  `dfs_user_about` text,
  PRIMARY KEY (`dfs_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('025107b6-82ad-47de-9848-2c73eef6d721','Pallavi','USER','Intern at IIIT Hyderabad. Undergrad at NIT'),('56106f4d-a316-4871-b7ec-3f3eb85e3a65','Garry','USER','Garry, a research student at IIIT Hyderabad.'),('5c4a30ca-b253-4fc4-b2a8-258f0b482fa3','Arpit','USER','Intern at IIIT Hyderabad. Loves anime'),('aee44668-b6e8-4c84-8099-8551fff5cda5','Rajat','USER','Intern, interested in datasets'),('d23a3e1c-bc46-4405-bfbe-2fd2af957176','Amit','ADMIN','Project Coordinator for DFS.');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-20 18:34:01