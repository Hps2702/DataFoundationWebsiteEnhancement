import { Heading } from "../../components/styled/Text";
import { withAuth } from "../../withAuth";
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook

const Me = ({ user }) => {
  const { darkTheme } = useTheme(); // Access the theme state
  const textClass = darkTheme ? 'darkmode-text bg-lt-dark' : 'bg-white';
  const backgroundclass = darkTheme ? 'px-3 py-1 break-words border border-shade-400 bg-card-dark' : 'px-3 py-1 break-words bg-table-shade border border-shade-400';
  const backgrounddata = darkTheme ? 'px-3 py-1 break-words border border-shade-400 bg-lt-dark' : 'px-3 py-1 break-words bg-white border border-shade-400';

  // console.log(user);
  return <div className="flex flex-col gap-y-7 my-7 w-full px-10">
    <div className={`w-full rounded-xl p-6 ${textClass}`}>
      <Heading>User Details</Heading>
      <table className="w-full">
        <tr>
          <td className={backgroundclass}> First Name </td>
          <td className={backgrounddata}>{user.user.first_name}</td>
        </tr><tr>
          <td className={backgroundclass}> Last Name </td>
          <td className={backgrounddata}>{user.user.last_name}</td>
        </tr><tr>
          <td className={backgroundclass}> Registered Email </td>
          <td className={backgrounddata}>{user.user.user_email}</td>
        </tr><tr>
          <td className={backgroundclass}> Institution </td>
          <td className={backgrounddata}>{user.user.institution}</td>
        </tr><tr>
          <td className={backgroundclass}> Designation </td>
          <td className={backgrounddata}>{user.user.designation}</td>
        </tr><tr>
          <td className={backgroundclass}> Role (DFS) </td>
          <td className={backgrounddata}>{user.user.user_role}</td>
        </tr>
      </table>
    </div></div>;
};

export default withAuth(Me);
