import React from "react";
import { useState } from "react";
import MyDatasets from "../../components/homepage/myDatasets";
import MyModels from "../../components/homepage/myModels";
import MyRequests from "../../components/homepage/myRequests";
import MyPermissionRequests from "../../components/homepage/myPermissionRequests";
import { withAuth } from "../../withAuth";
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook

function HomePage() {
  const [copiedTimeoutId, setCopiedTimeoutId] = useState(-1);
  const [copiedIndex, setCopiedIndex] = useState(-1);
  const [showCopied, setShowCopied] = useState(false);
  const { darkTheme } = useTheme(); // Access the theme state
  const textClass = darkTheme ? 'darkmode-text' : '';
  const backgroundclass = darkTheme ? 'bg-lt-dark' : 'bg-white';
 
  return (
    <>
      <div className={`flex flex-col gap-y-7 my-7 ${textClass}`}>
        <div className={`w-full rounded-xl p-6 ${backgroundclass}`}>
          <MyDatasets
          className={backgroundclass}
            copiedTimeoutId={copiedTimeoutId}
            copiedIndex={copiedIndex}
            showCopied={showCopied}
            setCopiedIndex={setCopiedIndex}
            setShowCopied={setShowCopied}
            setCopiedTimeoutId={setCopiedTimeoutId}
          />
        </div>
        <div className={`w-full rounded-xl p-6 ${backgroundclass}`}>
          <MyModels
            copiedTimeoutId={copiedTimeoutId}
            copiedIndex={copiedIndex}
            showCopied={showCopied}
            setCopiedIndex={setCopiedIndex}
            setShowCopied={setShowCopied}
            setCopiedTimeoutId={setCopiedTimeoutId}
          />
        </div>
        <div className={`w-full rounded-xl p-6 ${backgroundclass}`}>
          <MyRequests />
        </div>
        <div className={`w-full rounded-xl p-6 ${backgroundclass}`}>
          <MyPermissionRequests />
        </div>
      </div>
    </>
  );
}

export default withAuth(HomePage);
