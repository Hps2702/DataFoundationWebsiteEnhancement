import seg1 from '../../assets/idd/seg1.jpg';
import seg2 from '../../assets/idd/seg2.jpg';
import det from '../../assets/idd/det.jpg';
import lite from '../../assets/idd/lite.jpg';
import mmodal from '../../assets/idd/mmodal.jpg';
import train from '../../assets/idd/train.jpg';
import test from '../../assets/idd/test.jpg';
import val from '../../assets/idd/val.jpg';

export {
    seg1,
    seg2,
    det,
    lite,
    mmodal,
    train,
    test,
    val,
};