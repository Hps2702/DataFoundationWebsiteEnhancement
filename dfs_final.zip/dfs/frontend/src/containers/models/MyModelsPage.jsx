import AllModels from '../../components/datamodels/AllModels';

export default function MyModelsPage(){
  return <>
    <AllModels />
  </>;
}