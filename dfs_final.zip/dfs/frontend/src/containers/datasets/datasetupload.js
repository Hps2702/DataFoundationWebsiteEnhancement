import axios from "axios";
import React, { useEffect, useState } from "react";
import creds from "../../creds";
const url= creds.backendUrl;


export default function datasetUpload({domain}){
  const [data, setData] = useState([]);
  return(<>
    <h1>ASDF</h1>
  </>);
}