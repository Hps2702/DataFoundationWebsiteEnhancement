import React, { useState, memo } from "react";
import ExpandedVersionTable from "./ExpandedTable";
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook

function DatasetVersionDetails(props) {
  const [isExpanded, setIsExpanded] = useState(false);
  const { darkTheme } = useTheme(); // Access the theme state
  const textClass = darkTheme ? 'darkmode-text' : 'text-fn-blue';
  const backgroundclass = darkTheme ? 'bg-lt-dark' : 'bg-white';
  const backgroundhead = darkTheme ? 'bg-card-dark text-white' : 'bg-gray-100 text-gray-600';
 
  return (
    <div>
      <div className="items-center w-full justify-center" data-color-mode="light">
        {!isExpanded && (
          <div className={`items-center ${textClass}`}>
            
            <div className="column">

              <p className={`flex flex-col text-center pt-2  rounded-xl ${backgroundclass}`}>
              <h4 className=" underline">Dateset Version Details</h4>
                <span className="text-2xl text-center align-center font-bold">
                  {props.data.version_name}{" "}
                </span>
                <span className="text-lg ml-1">
                  {props.data.upfilename}
                </span>
                <button
                  className="gradient__text text-lg border-none mb-3"
                  onClick={()=>setIsExpanded(!isExpanded)}
                >
                   Expand{'->'}
                </button>
              </p>
            </div>
          </div>
        )}

        {isExpanded && (
          <div className={`mb-4 py-4 px-4 ${backgroundclass}`}>
          <h2 className={`text-center ${textClass}`}>Dataset Version Details</h2>
            <button
              className="items-center align-center text-center mt-2 gradient__text text-lg border-none mb-2"
              onClick={()=>setIsExpanded(!isExpanded)}
            >
              Shrink{'->'}
            </button>
            <ExpandedVersionTable
              fileType={props.data.filetype}
              upfilename={props.data.upfilename}
              upfilenameMD={props.data.upfilenameMD}
              databaseId={props.data.database_id}
              databaseVersionId={props.data.databaseVersion_id}
              comments={props.data.comments}
              versionName = {props.data.version_name}
              reference={props.data.reference}
              createdDate={props.data.created_date}
              lastEdit={props.data.last_edit}
              publicationName={props.data.publication_names}
              publicationLinks={props.data.publication_links}
              verification={props.data.verification}
              authorId={props.data.author_id}
            />
          </div>
        )}
      </div>
    </div>
  );
}
export default memo(DatasetVersionDetails);
