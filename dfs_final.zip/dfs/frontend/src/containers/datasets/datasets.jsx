import axios from "axios";
import React, { useEffect, useState,useContext } from "react"
import { Link } from 'react-router-dom'
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook
import { ToastContext } from "../../App";
import { TOAST_VARIANTS } from "../../packages/toasts/constants";
import AllDatasets from "../../components/datasets/allDatasets";
import DomainData from "./domains";
import { DatasetFont, SubHeading, ReferenceFont, Heading } from "../../GlobalStyles";
import creds from "../../creds";
import ContentLoader from "react-content-loader";
import { DomainDataTombstone } from "../../components/tombstones/DomainDataTombstone";
const url= creds.backendUrl;

export default function DatasetsPage() {
  const { darkTheme } = useTheme(); // Access the theme state
  const textClass = darkTheme ? 'darkmode-text' : '';
  const backgroundclass = darkTheme ? 'bg-lt-dark' : 'bg-lt';
  const backgroundsearch = darkTheme ? 'bg-card-dark' : 'bg-gray-50';
  const { addToast } = useContext(ToastContext);
  const [domains, setDomains] = useState([]);
  const [searchq, setSearchq] = useState('');
  const [searchd, setSearchd] = useState('');
  const [searchf,setSearchf]  = useState(false)
  const [dset,setDset] = useState([]);
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  let user = JSON.parse(localStorage.getItem('dfs-user'));
  const isLoggedIn = !!localStorage.getItem("dfs-user");

  console.log(domains);
  useEffect(()=>{
    setLoading(true);
 if(searchf === false) {  axios.get(url + 'domains', {
      params : {searchq}, 
    })
    .then(res=>{
      console.log(res);
      setDomains(res.data.data);
    }).catch(err => {
      console.log('UPDATE THIS TO TOAST', err);
    })
    .finally(()=>{
      setLoading(false);
    });
  }
  if(searchf===true)
{  axios.get(url + 'searchdataset', {
      params : {searchd}, 
    })
    .then(res=>{
      console.log(res);
      setDset(res.data.data);
    }).catch(err => {
      console.log('UPDATE THIS TO TOAST', err);
    })
    .finally(()=>{
      setLoading(false);
      
    });
  }
    console.log(dset)
  }, [searchq,searchd]);
  return (<>
    <div className={`pt-1 px-5 m-5 ${textClass}`}>
      <div className="mb-12">
        <h1 className={darkMode ?  Heading + ' darkmode-text text-center' : Heading + '  text-center'}>Available Data Sets</h1>
        <div class={` flex items-center  m-2 rounded-25 px-3 border ${backgroundsearch}`}>
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400 " viewBox="0 0 20 20"
            fill="currentColor">
            <path fill-rule="evenodd"
              d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
              clip-rule="evenodd" />
          </svg>
          <input class={`border-none outline-none ml-1 block float-right flex-1 ${backgroundsearch}`} type="text" value={searchq} onChange={e=>{setSearchq(e.target.value);setSearchf(false);}} placeholder="Search Domain" />
          
        </div>
        <div class={` flex items-center  m-2 rounded-25 px-3 border ${backgroundsearch}`}>
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400 " viewBox="0 0 20 20"
            fill="currentColor">
            <path fill-rule="evenodd"
              d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
              clip-rule="evenodd" />
          </svg>
          <input class={`border-none outline-none ml-1 block float-right flex-1 ${backgroundsearch}`} type="text" value={searchd} onChange={e=>{setSearchd(e.target.value);setSearchf(true);}} placeholder="Search Dataset" />

        </div>
      </div>
      {loading ? (
        <div>
          {
            [1, 2, 3].map((k) => (
              <div key={k} className="mb-12">
                <h1 className="gradient__text mt-2 text-5xl py-2 tracking-tight text-gray-900 sm:text-5xl flex-1 mb-8">
                  <ContentLoader height="50px" width="40%" foregroundColor="#dedede">
                    <rect height="100%" width="100%" rx="10" ry="10" />
                  </ContentLoader>
                </h1>
                <p className={DatasetFont} >
                  <ContentLoader height="20px" width="100%" foregroundColor="#dedede">
                    <rect height="100%" width="100%" rx="2px" ry="2px" />
                  </ContentLoader>
                  <ContentLoader height="20px" width="100%" className="mt-1" foregroundColor="#dedede">
                    <rect height="100%" width="100%" rx="2px" ry="2px" />
                  </ContentLoader>
                </p>
                <p className={DatasetFont + ' pt-1 mb-8 pb-3'}>
                  <ContentLoader height="20px" width="100%" foregroundColor="#dedede">
                    <rect height="100%" width="100%" rx="2px" ry="2px" />
                  </ContentLoader>
                </p>
                <DomainDataTombstone />
                <DomainDataTombstone />
                <DomainDataTombstone />
                <div className="mb-10 " />
              </div>
            ))
          }
        </div>
      ) : searchf ? (
        dset.map((dataset, index) => (
          <div
            class="max rounded overflow-hidden shadow-2xl hover:shadow-3xl text-center mb-8"
            key={index}
          >
            <div class="px-6 py-4">
              <div class="font-bold text-3xl mb-4">{dataset.dataset_name}</div>
              <p class="text-gray-700 text-base mb-4 text-justify">
                {dataset.dataset_description && dataset.dataset_description.split('Π').map((data) => (<p className="mb-2">{data}</p>))}
              </p>
              {(dataset.source.includes('http') || dataset.source.includes('www')) ? <a class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full m-1"
                href={dataset.source}
              >
                Source
              </a> : null}
              <a
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-full m-1"
                href={"/dataset-versions/" + dataset.dataset_id}
              >
                Details
              </a>
              <button
                class="bg-yellow-500 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded-full m-1 mt-2"
                onClick={() => {
                  if (!isLoggedIn) {
                    addToast({
                      message: "Sign In Required to Download",
                      variant: TOAST_VARIANTS.ERROR
                  });
                  }
                  else {
                    window.location.href = url + "request-new-dataset?datasetid=" + dataset.dataset_id + "&token=" + (isLoggedIn ? JSON.parse(localStorage.getItem("dfs-user"))["token"] : null);
                  }
                }}
              >
                Download
              </button>
            </div>
          </div>
        ))
      ) : (
        <div>
          {domains.map((domain, key) => (<div key={key} className={`mb-12 pt-4 px-5 pb-2 rounded-50 ${backgroundclass}`}>
            <h1 className={`${SubHeading} mt-2 py-2 pt-0 mb-8`}>{domain.domain}</h1>
            {domain.abstract_a && <p className={DatasetFont} >{domain.abstract_a}</p>}
            {domain.abstarct_b && <p className={DatasetFont} >{domain.abstarct_b}</p>}
            {domain.abstract_c && <p className={DatasetFont} >{domain.abstract_c}</p>}
            {domain.publication_names && domain.publication_links && <><p className={`${ReferenceFont} pt-2`}>{domain.publication_names} <a href={domain.publication_links}><span className="text-red-500">[{domain.publication_format}]</span></a></p></>}
            <div className="mb-10 " />
            <DomainData domain={domain.domain} /> <br /> <br />
          </div>))}
        </div>
      )}

    </div>
  </>);
}
