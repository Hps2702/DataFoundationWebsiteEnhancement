import axios from "axios";
import React, { useEffect, useState, useContext } from "react";
import download from "js-file-download";
import creds from "../../creds";
import { useNavigate } from "react-router-dom";
import ContentLoader from "react-content-loader";
import { DomainDataTombstone } from "../../components/tombstones/DomainDataTombstone";
import { ToastContext } from "../../App";
import { TOAST_VARIANTS } from "../../packages/toasts/constants";
import { Heading } from "../../components/styled/Text";
import 'bootstrap/dist/css/bootstrap.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook

function MyVerticallyCenteredModal(props) {
  const { datasetName, datasetDescription, show, onHide } = props;
  const { darkTheme } = useTheme(); // Access the theme state
 
  return (
    <Modal
      show={show}
      onHide={onHide}
      style={{ backdropFilter: "blur(3px)" }}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      className={darkTheme ? "custom-modal" : ""}
      centered
    >
      <Modal.Header closeButton>
        <Modal.Title id="contained-modal-title-vcenter">
          {datasetName}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>
          {datasetDescription}
        </p>
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={onHide}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}




// const url= creds.backendUrl;
const url = creds.backendUrl;

export default function DomainData({ domain }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  const { addToast } = useContext(ToastContext);
 
  const isLoggedIn = !!localStorage.getItem("dfs-user");
  const [data, setData] = useState([]);
  const [modalShow, setModalShow] = useState(Array(data.length).fill(false));
  const { darkTheme } = useTheme(); // Access the theme state
  const backgroundclass = darkTheme ? 'bg-card-dark' : 'bg-lt-1';
  
  useEffect(() => {
    setLoading(true);
    axios
      .get(url + "datasets", { params: { domain } })
      .then((data) => {
        // console.log("DATA", domain, data);
        setData(data.data.data);
      })
      .catch((err) => {
        // console.log("ERR", err);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [domain]);

  if (!loading && data.length === 0) {
    return <Heading size="2" className="text-red-900 text-center">No verified public datasets visible for above domain</Heading>
  }
 
  return (
    <>
      {/* console.log(data); */}
      {loading ? (
        [1, 2, 3].map((k) => (
          <DomainDataTombstone key={k} />
        ))
      ) :
        (<div className="card-container">
          {
            data.map((dataset, index) => (
              <div
                class={`max overflow-hidden  hover:shadow-xl rounded-20 text-center mb-8 ${backgroundclass}`}
                key={index}
              >
                <div class="px-6 py-4">
                  <div class="font-bold text-lg mb-4">{dataset.dataset_name}</div>

                  {/* <p class="text-gray-700 text-sm mb-4 text-justify">
                    {dataset.dataset_description && dataset.dataset_description.split('Π').map((data) => (<p className="mb-2">{data}</p>))}
                  </p> */}
                  <p class={darkTheme ? "darkmode-text text-sm mb-4 text-justify" : "text-gray-700 text-sm mb-4 text-justify"}>
                    {dataset.dataset_description && dataset.dataset_description.split(' ').slice(0, 80).join(' ')}
                    {dataset.dataset_description.split(' ').length > 80 && '...'}
                    <p style={{
                      color: '#5a8afa',
                      cursor: 'pointer',
                    }} variant="primary" onClick={() => setModalShow((prevState) => {
                      const newState = [...prevState];
                      newState[index] = true;
                      return newState;
                    })}>
                      Read More
                    </p>
                  </p>

                  <MyVerticallyCenteredModal
                    show={modalShow[index]}
                    onHide={() => setModalShow((prevState) => {
                      const newState = [...prevState];
                      newState[index] = false;
                      return newState;
                    })}
                    datasetName={dataset.dataset_name}
                    datasetDescription={dataset.dataset_description}
                  />
                  {(dataset.source.includes('http') || dataset.source.includes('www')) ? <a 
                  class="dec-none hover:bg-blue-500 text-primary border border-primary font-bold py-2 px-4 rounded m-1"
                    href={dataset.source}
                  >
                    Source
                  </a> : null}
                  

                  <button
                    class="dec-none hover:bg-red-500 border border-danger text-danger  font-bold py-2 px-4 rounded m-1"
                    onClick={() => {
                      if (!isLoggedIn) {
                        addToast({
                          message: "Sign In Required to Download",
                          variant: TOAST_VARIANTS.ERROR
                        });
                      }
                      else {
                        window.location.href = url + "request-new-dataset?datasetid=" + dataset.dataset_id + "&token=" + (isLoggedIn ? JSON.parse(localStorage.getItem("dfs-user"))["token"] : null);
                      }
                    }}
                  >
                    Download
                  </button>

                  <a
                    class={ darkTheme ? "dec-none hover:bg-orange-500 border border-warning text-warning font-bold py-2 px-4 rounded m-1": "dec-none bg-orange-400 hover:bg-orange-500 border border-warning  text-light font-bold py-2 px-4 rounded m-1"}
                    href={"/dataset-versions/" + dataset.dataset_id}
                  >
                    Details 
                  </a>
                </div>
              </div>
            ))
          }
        </div>)}
    </>
  );
}
