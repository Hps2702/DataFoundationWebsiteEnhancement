import axios from "axios";
import React, { useEffect, useState, useContext } from "react";
import download from "js-file-download";
import creds from "../../creds";
import { useNavigate } from "react-router-dom";
import ContentLoader from "react-content-loader";
import { DomainDataTombstone } from "../../components/tombstones/DomainDataTombstone";
import { ToastContext } from "../../App";
import { TOAST_VARIANTS } from "../../packages/toasts/constants";
import { Heading } from "../../components/styled/Text";
import 'bootstrap/dist/css/bootstrap.css';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook
// const url= creds.backendUrl;
const url = creds.backendUrl;
export default function PaymentCard({ }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  const { addToast } = useContext(ToastContext);
 
  const isLoggedIn = !!localStorage.getItem("dfs-user");
  const [data, setData] = useState([]);
  const [modalShow, setModalShow] = useState(Array(data.length).fill(false));
  const { darkTheme } = useTheme(); // Access the theme state
  const backgroundclass = darkTheme ? 'bg-card-dark' : 'bg-lt-1';

	const initPayment = (data) => {

		const options = {
      key: 'rzp_test_nHHGePXle5wimV',
      amount: data.amount,
      currency: data.currency,
      name: 'Buy Subscription',
      description: "Test Transaction",
      image:  './ihub.png',
			order_id: data.id,
			handler: async (response) => {
				try {
					// const verifyUrl = "http://localhost:8080/api/payment/verify";
          const verifyUrl = url + "verify"
          console.log(verifyUrl)
					const { data } = await axios.post(verifyUrl, response);
					console.log(data);
					if (data.message === "Payment verified successfully") {
						// alert("database added")
            addToast({
              message: "Payment verified successfully",
              variant: TOAST_VARIANTS.SUCCESS
            });
					  }
          else {
            addToast({
              message: "Something went wrong",
              variant: TOAST_VARIANTS.WARNING
            });
          }

				} catch (error) {
					console.log(error);
				}
			},
			theme: {
				color: "#3399cc",
			},
		};
		const rzp1 = new window.Razorpay(options);
		rzp1.open();
	};

  
  async function handlePayment(price) {
    try {
      // const orderUrl = "http://localhost:8080/api/payment/orders";
      const orderUrl = url + "orders"
      console.log(orderUrl)
      const { data } = await axios.post(orderUrl, { amount: price });
      console.log(data);
      initPayment(data.data);
    } catch (error) {
      console.log(error);
    }
  }
  
 
  return (
    <>
      <div className="card-container" style={{ width: '80%',  margin: 'auto', display: 'flex', flexDirection: 'row' }}>

  <>
    <div
      class={`max overflow-hidden hover:shadow-xl rounded-20 text-center mb-8 ${backgroundclass}`}
      style={{ backgroundColor: '#DDDDDD' }}
    >
      <div class="px-6 py-4">
        <div class="font-bold text-lg mb-4">Premium Access</div>
        <p>Upgrade to Premium Access for a premium experience. Enjoy an ad-free environment, early access to content, and exclusive premium features that enhance your user experience.</p>
             
        <button
          class="dec-none hover:bg-red-500 border border-danger text-danger font-bold py-2 px-4 rounded m-1"
          onClick={() => handlePayment(5000)}
        >
         Buy
        </button>

        <a
          class={
            darkTheme
              ? "dec-none hover-bg-orange-500 border border-warning text-warning font-bold py-2 px-4 rounded m-1"
              : "dec-none bg-orange-400 hover-bg-orange-500 border border-warning text-light font-bold py-2 px-4 rounded m-1"
          }
        >
          Details
        </a>
      </div>
    </div>
  </>

  {/* Duplicate the above code for additional cards */}
  <>
    <div
      class={`max overflow-hidden hover:shadow-xl rounded-20 text-center mb-8 ${backgroundclass}`}
      style={{ backgroundColor: '#DDDDDD' }}
    >
      <div class="px-6 py-4">
        <div class="font-bold text-lg mb-4">Subscription</div>
        <p>Subscribe today for seamless access to our service. Choose from flexible monthly or annual plans to ensure you never miss out on the latest updates, features, and content.</p>
        <button onClick={() => handlePayment(250)}
          class="dec-none hover:bg-red-500 border border-danger text-danger font-bold py-2 px-4 rounded m-1"
        >
         Buy
        </button>

        <a
          class={
            darkTheme
              ? "dec-none hover-bg-orange-500 border border-warning text-warning font-bold py-2 px-4 rounded m-1"
              : "dec-none bg-orange-400 hover-bg-orange-500 border border-warning text-light font-bold py-2 px-4 rounded m-1"
          }
        >
          Details
        </a>
      </div>
    </div>
  </>

  {/* Duplicate the above code for additional cards */}
  <>
    <div
      class={`max overflow-hidden hover:shadow-xl rounded-20 text-center mb-8 ${backgroundclass}`}
      style={{ backgroundColor: '#DDDDDD' }}
    >
      <div class="px-6 py-4">
        <div class="font-bold text-lg mb-4">Buy Dataset </div>
        <p>Need specific data? Purchase a single dataset for one-time access. Get instant access to valuable information that suits your needs without any ongoing commitment.</p>
        <button 
          class="dec-none hover:bg-red-500 border border-danger text-danger font-bold py-2 px-4 rounded m-1"
        >
          Buy
        </button>

        <a
          class={
            darkTheme
              ? "dec-none hover-bg-orange-500 border border-warning text-warning font-bold py-2 px-4 rounded m-1"
              : "dec-none bg-orange-400 hover-bg-orange-500 border border-warning text-light font-bold py-2 px-4 rounded m-1"
          }
        >
          Details
        </a>
      </div>
    </div>
  </>
</div>
    </>
  );
}
