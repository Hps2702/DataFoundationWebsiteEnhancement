import React from "react";
import "./Home.css";
import homeConfig from "./homeConfig.json";
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook

import {
  Heading,
  ParaFont,
  ParaHeading,
  FlexSection,
} from "../../GlobalStyles";
const Home = () => {
  const { darkTheme } = useTheme(); // Access the theme state
  const textClass = darkTheme ? 'darkmode-text' : '';
  const backgroundclass = darkTheme ? 'bg-lt-dark' : 'bg-lt';
  return (
    <div className={`px-5 m-5 ${textClass}`} id="home" >
        <h1 className={Heading + ' text-center'}>{homeConfig[0].HeadingText}</h1>
        <p className={ParaFont}>{homeConfig[0].Paragraphs[0]}</p>
        <p className={ParaFont}>{homeConfig[0].Paragraphs[1]}</p>
        <h3 className="font-extrabold text-center text-[2rem] tracking-tighter mt-6 text-regal-blue py-3 ">{homeConfig[1].SubHeadingText}</h3>
      {homeConfig.slice(2).map(({ id, Paragraphs, SubHeadingText }) => (
        <div key={id} className={` p-5 pt-3 my-2 rounded-25 ${backgroundclass}`}>
          <h3 className={ParaHeading}>{SubHeadingText}</h3>
          {Paragraphs.map((paragraph, index) => (
            <p className={ParaFont} key={`p-${index}`}>{paragraph}</p>
          ))}
        </div>
      ))}
    </div>
  );
};

export default Home;
