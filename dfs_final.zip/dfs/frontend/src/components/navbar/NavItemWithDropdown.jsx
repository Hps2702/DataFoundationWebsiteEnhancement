import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { BiChevronDown } from "react-icons/bi";

export const NavItemWithDropdown = ({
  navItemConfig,
  pathname,
  isDropDown,
}) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const isActive = navItemConfig.options.some(
    (navItemOption) => navItemOption.pathname === pathname
  );

  // Use a ref to keep a reference to the button element
  const buttonRef = useRef(null);

  useEffect(() => {
    setShowDropdown(false);

    // Add a click event listener to the document
    const handleClickOutside = (e) => {
      if (buttonRef.current && !buttonRef.current.contains(e.target)) {
        setShowDropdown(false);
      }
    };

    // Attach the event listener when the component mounts
    document.addEventListener("click", handleClickOutside);

    // Remove the event listener when the component unmounts
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, [pathname]);

  return (
    <button
      ref={buttonRef}
      className={
        isActive
          ? "dec-none text-blue-500 focus:outline-0 text-base"
          : "dec-none text-white focus:outline-0 text-base"
      }
      onClick={() => {
        setShowDropdown((a) => !a);
      }}
    >
      <span className="dec-none flex items-center hover:underline">
        <span>{navItemConfig.name}</span> <BiChevronDown />
      </span>
      {showDropdown ? (
        <div
          className={`dec-none bg-blue-green-1 pl-3 flex flex-col items-start gap-2 pb-3 mt-2 pt-2 ${
            isDropDown ? "" : "absolute drop-top pr-4"
          }`}
        >
          {navItemConfig.options.map((navItemOptionConfig) => {
            const className =
              pathname === navItemOptionConfig.pathname
                ? "text-blue-500 text-left dec-none"
                : "text-white text-left dec-none";
            return navItemOptionConfig.redirect ? (
              <a className={className} href={navItemOptionConfig.pathname}>
                {navItemOptionConfig.name}
              </a>
            ) : (
              <Link className={className} to={navItemOptionConfig.pathname}>
                {navItemOptionConfig.name}
              </Link>
            );
          })}
        </div>
      ) : null}
    </button>
  );
};
