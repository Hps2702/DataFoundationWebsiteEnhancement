import React from "react";
import { Link } from "react-router-dom";
import { datasetDetailsValueMap, datasetDetailsMap } from "../utils";
import { useTheme } from '../../../ThemeContext'; // Import the useTheme hook

const DatasetDetailsTable = ({
  targetElement,
  showFileDetails,
  allowEditTnc,
  reqstatus,
  acceptTnc,
  download_url,
  setAcceptTnc,
  download_readme_url,
}) => {
  const { darkTheme } = useTheme(); // Access the theme state
  const textClass = darkTheme ? 'darkmode-text' : 'text-gray-900';
  const backgroundclass = darkTheme ? 'bg-lt-dark' : 'bg-table-shade';
  const backgroundhead = darkTheme ? 'bg-card-dark text-white' : 'bg-gray-100 text-gray-600';
 
  return (
    <table className={`mb-2 border-collapse border border-shade-400 w-full ${textClass} `}>
      <tbody>
        {Object.keys(targetElement ?? {})
          .filter((key) => key !== "upfilename" && key !== "upfilenameMD" && key !== "additional")
          .map((key) => (
            <tr key={key}>
              <td className={`px-3 py-1 break-words border border-shade-400 ${backgroundclass}`}>
                {datasetDetailsMap(key)}
              </td>
              <td className="px-3 py-1 break-words border border-shade-400">
                {datasetDetailsValueMap(key, targetElement[key], {
                  reqstatus,
                  acceptTnc,
                  download_url,
                  setAcceptTnc,
                  download_readme_url,
                })}
              </td>
            </tr>
          ))}
        {allowEditTnc ? (
          <tr>
            <td className={`px-3 py-1 break-words border border-shade-400 ${backgroundclass}`}>
              Edit TNC Link:{" "}
            </td>
            <td className="px-3 py-1 break-words border border-shade-400">
              <Link
                to={`/tnc-edit/${targetElement?.upfilename}`}
                className="text-blue-500"
              >
                TNC EDIT LINK
              </Link>
            </td>
          </tr>
        ) : null}
      </tbody>
    </table>
  );
};

export { DatasetDetailsTable }
