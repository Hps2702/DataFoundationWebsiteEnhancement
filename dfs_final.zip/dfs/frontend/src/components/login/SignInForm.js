import axios from "axios";
import React, { useState, useContext } from "react";
import { Link, Navigate } from 'react-router-dom'
// import "./main.css"

import "./signin.css"
import { url } from "../../creds.js";

import { ToastContext } from "../../App";
import { TOAST_VARIANTS } from "../../packages/toasts/constants";
import { useTheme } from '../../ThemeContext'; // Import the useTheme hook


export default function SignInForm(){
  const { darkTheme } = useTheme(); // Access the theme state
  const textClass = darkTheme ? 'darkmode-text rounded-lg border' : 'text-gray-900';
  const background = darkTheme ? 'bg-lt-dark ' : '';
  const backgroundinput = darkTheme ? 'bg-card-dark' : '';
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const form_class = "px-4 py-4 mx-4 my-4 border border-solid border-current rounded-lg bg-white shadow-sign-in"

  const { addToast } = useContext(ToastContext);

  const submit = e => {
    e.preventDefault();
    console.log(email, password);
    axios.post(url + 'login', {email, password})
    .then(res => {
      console.log(res.data);
      addToast({
        message: "Login Successful",
        variant: TOAST_VARIANTS.SUCCESS
      });
      localStorage.setItem('dfs-user', JSON.stringify(res.data.data));
      setEmail('');
      setPassword('');
    }).catch(err => {
      if(err.message) {
        addToast({
          message: "Wrong Email or Password",
          variant: TOAST_VARIANTS.WARNING
        });
    }
      else {
        addToast({
          message: "UNEXPECTED ERROR, PROBABLY SERVER UNAVAILABLE",
          variant: TOAST_VARIANTS.ERROR
        })
      }
    })
  }
  if(localStorage.getItem('dfs-user')) return <Navigate to="/my-data" replace={true} />
  return (
      <div  style={{ width: '35%' }} className={`${textClass}`} >
        
        <div className={`container ${background}`}>
    <div class="title">Login</div>
    <div class="content">
      <form action="#" onSubmit={submit}>
        <div class="user-details" style = {{marginLeft : '20%'}}>
            <div class="input-box" style={{ width: '80%', marginBottom: '15px' }}>
              <span class="details">Email</span>
              <input type="email" 
                    onChange={e=>setEmail(e.target.value)}
                    value={email}
                    className={`${backgroundinput}`}
                    placeholder="Enter your email" required/>
            </div>
            <div class="input-box" style={{ width: '80%', marginBottom: '15px' }}>
              <span class="details">Password</span>
              <input type="password" 
              value={password}
              className={`${backgroundinput}`}
              onChange={e=>setPassword(e.target.value)}
              placeholder="Enter your password" required/>
          </div>
        </div>


        <div class="button">
          <input type="submit" value="Register"/>
        </div>
      </form>
    </div>
  </div>

      </div>
    );
};
