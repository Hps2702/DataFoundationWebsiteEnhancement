const creds = {
  // backendUrl: 'https://datafoundation.iiit.ac.in/api/',
  backendUrl: "http://localhost:3001/api/",
  // backendUrl: 'http://10.4.25.20:3001/api/',
};
export const url = creds.backendUrl;
export default creds;